/* =====================================================
   SASTAGO ANDROID BILL TOOLS
   ANDROID GALLERY SAVE / SHARE / 58MM PRINT
   BROWSER FALLBACK INCLUDED
   ===================================================== */

import { Capacitor } from "@capacitor/core";
import { FileSharer } from "@capgo/capacitor-file-sharer";
import { Printer } from "@capgo/capacitor-printer";
import { Filesystem, Directory } from "@capacitor/filesystem";

function isAndroidApp() {
    return Capacitor.isNativePlatform() && Capacitor.getPlatform() === "android";
}

function requireAndroid() {
    return isAndroidApp();
}

function notify(message, type = "success") {
    if (window.sastagoShowToast) {
        window.sastagoShowToast(message, type);
    } else {
        alert(message);
    }
}

function findOrder(orderId) {
    const orders = window.sastagoCustomerOrders || [];
    return orders.find(order => String(order.id) === String(orderId) || String(order.orderNumber) === String(orderId));
}

function createCanvas(order) {
    if (typeof window.sastagoCreateBillCanvas !== "function") {
        throw new Error("Bill generator is not connected.");
    }

    return window.sastagoCreateBillCanvas(order);
}

function getFileName(order) {
    const number = String(order.orderNumber || order.id)
        .replace(/[^a-zA-Z0-9-]/g, "");

    return `SastaGo-${number}.png`;
}

// Convert the canvas directly to canonical PNG base64. This avoids Blob/FileReader
// edge cases that can produce ERR_PARAM_DATA_INVALID in the Android native decoder.
function getPngBase64(canvas) {
    if (!canvas || !canvas.width || !canvas.height || typeof canvas.toDataURL !== "function") {
        throw new Error("Bill image is empty or PNG conversion is unavailable.");
    }
    const dataUrl = canvas.toDataURL("image/png");
    const comma = dataUrl.indexOf(",");
    if (comma < 0 || !dataUrl.slice(0, comma).toLowerCase().startsWith("data:image/png;base64")) {
        throw new Error("Bill could not be converted to a PNG image.");
    }
    let raw = dataUrl.slice(comma + 1).replace(/\s/g, "").replace(/-/g, "+").replace(/_/g, "/");
    if (!raw || !/^[A-Za-z0-9+/]*={0,2}$/.test(raw)) {
        throw new Error("PNG image data contains invalid Base64 characters.");
    }
    while (raw.length % 4) raw += "=";
    let decoded;
    try { decoded = atob(raw); } catch (_) {
        throw new Error("PNG image Base64 could not be decoded. Please reopen the bill and try again.");
    }
    if (decoded.length < 8 || decoded.charCodeAt(0) !== 0x89 || decoded.slice(1, 4) !== "PNG") {
        throw new Error("Generated image is not a valid PNG file.");
    }
    return raw;
}

/* =====================================================
   DOWNLOAD BILL
   ===================================================== */

async function downloadOrderPNG(orderId) {
    try {
        const order = findOrder(orderId);

        if (!order) {
            throw new Error("Order not found.");
        }

        const canvas = createCanvas(order);
        const filename = getFileName(order);

        const base64Data = getPngBase64(canvas);
        if (requireAndroid()) {
            // Write the generated PNG to the app cache first, then give the
            // native FileSharer a real file URI (avoids its Base64 decoder path).
            const cached = await Filesystem.writeFile({
                path: filename,
                data: base64Data,
                directory: Directory.Cache,
                recursive: true
            });
            if (!cached?.uri) throw new Error("Bill PNG temporary file could not be created.");
            const result = await FileSharer.save({
                filename,
                contentType: "image/png",
                path: cached.uri,
                android: { saveDirectory: "pictures", relativePath: "SastaGo Bills" }
            });
            notify("Bill Gallery ke Pictures/SastaGo Bills folder mein save ho gaya!");
            console.log("Saved bill:", result?.uri);
        } else {
            const link = document.createElement("a");
            link.href = `data:image/png;base64,${base64Data}`;
            link.download = filename;
            document.body.appendChild(link); link.click(); link.remove();
            notify("Bill PNG download ho gaya.");
        }

    } catch (error) {
        console.error("Bill Download Error:", error);
        notify(error.message || "Bill download failed.", "error");
    }
}

/* =====================================================
   SHARE BILL
   ===================================================== */

async function shareOrderPNG(orderId) {
    try {
        const order = findOrder(orderId);

        if (!order) {
            throw new Error("Order not found.");
        }

        const canvas = createCanvas(order);
        const filename = getFileName(order);

        const base64Data = getPngBase64(canvas);
        if (requireAndroid()) {
            await FileSharer.share({ filename, contentType: "image/png", base64Data,
                title: "SastaGo Order Bill", text: "SastaGo Order Bill" });
        } else {
            const blob = await (await fetch(`data:image/png;base64,${base64Data}`)).blob();
            const file = new File([blob], filename, { type: "image/png" });
            if (navigator.share && (!navigator.canShare || navigator.canShare({ files: [file] })))
                await navigator.share({ title: "SastaGo Order Bill", files: [file] });
            else { const link=document.createElement("a"); link.href=`data:image/png;base64,${base64Data}`; link.download=filename; document.body.appendChild(link); link.click(); link.remove(); }
        }

    } catch (error) {
        if (error.name === "AbortError") return;

        console.error("Bill Share Error:", error);
        notify(error.message || "Bill share failed.", "error");
    }
}

/* =====================================================
   PRINT 58MM BILL
   ===================================================== */

async function printOrderPNG(orderId) {
    try {
        const order = findOrder(orderId);

        if (!order) {
            throw new Error("Order not found.");
        }

        const canvas = createCanvas(order);

        const data = getPngBase64(canvas);
        if (requireAndroid()) {
            await Printer.printBase64({ name: getFileName(order), data, mimeType: "image/png" });
        } else {
            const w = window.open("", "_blank");
            if (!w) throw new Error("Print popup blocked. Please allow popups.");
            w.document.write(`<html><head><title>SastaGo Bill</title><style>@page{size:58mm auto;margin:0}body{margin:0}img{width:58mm;height:auto}</style></head><body><img src="data:image/png;base64,${data}" onload="setTimeout(()=>window.print(),250)"></body></html>`);
            w.document.close();
        }

    } catch (error) {
        console.error("Bill Print Error:", error);

        notify(error.message || "Bill printing failed.", "error");
    }
}

/* =====================================================
   GLOBAL FUNCTIONS
   ===================================================== */

window.downloadOrderPNG = downloadOrderPNG;
window.shareOrderPNG = shareOrderPNG;
window.printOrderPNG = printOrderPNG;

window.SastaGoCustomerBillTools = { downloadOrderPNG, shareOrderPNG, printOrderPNG, isAndroidApp };
console.log("SastaGo Bill Tools Initialized.", { android: isAndroidApp(), platform: Capacitor.getPlatform?.() });