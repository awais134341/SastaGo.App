const APP_CONFIG = {
    name: "SastaGo Admin",
    shortName: "SastaGo Admin",
    appType: "admin",
    icon: "./app-icons/admin-icon.png"
};

export default APP_CONFIG;