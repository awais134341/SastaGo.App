// =====================================================
// SASTAGO ADMIN PANEL - OPTIMIZED COMPLETE JAVASCRIPT
// Firebase v10.14.1
// Project: sastago-85c78
// =====================================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";

import {
  getAuth,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";

import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
  runTransaction
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

// =====================================================
// FIREBASE CONFIGURATION
// =====================================================

const firebaseConfig = {
  apiKey: "AIzaSyBspyu_v0mk35Gncw8iik3sXDZeStGDKJo",
  authDomain: "sastago-85c78.firebaseapp.com",
  databaseURL: "https://sastago-85c78-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "sastago-85c78",
  storageBucket: "sastago-85c78.firebasestorage.app",
  messagingSenderId: "711302128514",
  appId: "1:711302128514:web:8e247540108c53259be59b",
  measurementId: "G-RDNS7PJPB8"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// =====================================================
// HELPERS
// =====================================================

const $ = id => document.getElementById(id);

const value = id => $(id)?.value?.trim() || "";

const number = id => Number(value(id) || 0);

const money = amount =>
  "Rs. " + Number(amount || 0).toLocaleString("en-PK", {
    maximumFractionDigits: 2
  });

const safeText = text =>
  String(text ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);

const dateString = date => {
  if (!date) return "";
  if (date.toDate) date = date.toDate();

  const d = new Date(date);

  return Number.isNaN(d.getTime())
    ? ""
    : d.toLocaleDateString();
};

const showMessage = (id, message, error = false) => {
  const el = $(id);

  if (el) {
    el.textContent = message;
    el.style.color = error ? "#dc2626" : "#15803d";
  }
};

const on = (id, event, handler) => {
  $(id)?.addEventListener(event, handler);
};

const getCollection = async name => {
  const snap = await getDocs(collection(db, name));

  return snap.docs.map(item => ({
    id: item.id,
    ...item.data()
  }));
};

const activeAdmin = async uid => {
  const snap = await getDoc(doc(db, "admins", uid));

  return snap.exists() && snap.data().active === true;
};

// =====================================================
// APPLICATION DATA
// =====================================================

let products = [];
let categories = [];
let brands = [];
let orders = [];
let customers = [];
let expenses = [];
let suppliers = [];
let stockHistory = [];

let selectedBill = null;
let quantityTiers = [];

let isLoading = false;
let isAuthenticated = false;

const collectionPromises = new Map();

const CACHE_TIME = 60 * 1000;

// =====================================================
// FAST COLLECTION LOADER
// =====================================================

async function loadCollection(name, force = false) {

  if (!force && collectionPromises.has(name)) {
    return collectionPromises.get(name);
  }

  const promise = getCollection(name);

  collectionPromises.set(name, promise);

  try {
    return await promise;
  } finally {
    collectionPromises.delete(name);
  }
}

// =====================================================
// INITIAL DATA LOADING
// =====================================================

async function loadEverything() {

  if (isLoading) return;

  isLoading = true;

  try {

    const result = await Promise.allSettled([
      loadCollection("products", true),
      loadCollection("categories", true),
      loadCollection("brands", true),
      loadCollection("orders", true),
      loadCollection("customers", true),
      loadCollection("expenses", true),
      loadCollection("suppliers", true),
      loadCollection("stockHistory", true)
    ]);

    const names = [
      "products",
      "categories",
      "brands",
      "orders",
      "customers",
      "expenses",
      "suppliers",
      "stockHistory"
    ];

    result.forEach((item, index) => {

      if (item.status !== "fulfilled") {
        console.error(
          "Collection loading failed:",
          names[index],
          item.reason
        );
        return;
      }

      switch (names[index]) {
        case "products":
          products = item.value;
          break;

        case "categories":
          categories = item.value;
          break;

        case "brands":
          brands = item.value;
          break;

        case "orders":
          orders = item.value;
          break;

        case "customers":
          customers = item.value;
          break;

        case "expenses":
          expenses = item.value;
          break;

        case "suppliers":
          suppliers = item.value;
          break;

        case "stockHistory":
          stockHistory = item.value;
          break;
      }
    });

    renderEverything();

  } catch (error) {
    console.error("LOAD ERROR:", error);
    alert("Data loading error: " + error.message);
  } finally {
    isLoading = false;
  }
}

// =====================================================
// REFRESH ONLY REQUIRED COLLECTIONS
// =====================================================

async function refreshCollections(names = []) {

  if (!names.length) return;

  const loaders = names.map(name =>
    loadCollection(name, true)
  );

  const results = await Promise.allSettled(loaders);

  results.forEach((result, index) => {

    if (result.status !== "fulfilled") {
      console.error(
        "Refresh failed:",
        names[index],
        result.reason
      );
      return;
    }

    const name = names[index];

    switch (name) {
      case "products":
        products = result.value;
        break;

      case "categories":
        categories = result.value;
        break;

      case "brands":
        brands = result.value;
        break;

      case "orders":
        orders = result.value;
        break;

      case "customers":
        customers = result.value;
        break;

      case "expenses":
        expenses = result.value;
        break;

      case "suppliers":
        suppliers = result.value;
        break;

      case "stockHistory":
        stockHistory = result.value;
        break;
    }
  });

  fillSelects();

  names.forEach(name => {

    switch (name) {
      case "products":
        renderProducts();
        renderStock();
        renderDashboard();
        renderReports();
        break;

      case "categories":
        renderCategories();
        fillSelects();
        renderDashboard();
        break;

      case "brands":
        renderBrands();
        fillSelects();
        renderDashboard();
        break;

      case "orders":
        renderOrders();
        renderDashboard();
        renderReports();
        break;

      case "customers":
        renderCustomers();
        renderDashboard();
        break;

      case "expenses":
        renderExpenses();
        renderDashboard();
        renderReports();
        break;

      case "suppliers":
        renderSuppliers();
        break;

      case "stockHistory":
        renderStockHistory();
        break;
    }
  });
}

function renderEverything() {
  fillSelects();

  renderCategories();
  renderBrands();
  renderProducts();
  renderOrders();
  renderCustomers();
  renderExpenses();
  renderStock();
  renderSuppliers();
  renderStockHistory();
  renderDashboard();
  renderReports();
}

// =====================================================
// LOGIN SYSTEM
// =====================================================

let loginInProgress = false;

on("loginForm", "submit", async event => {

  event.preventDefault();

  if (loginInProgress) return;

  const email = value("email");
  const password = value("password");

  if (!email || !password) {
    return showMessage(
      "loginMsg",
      "Enter email and password.",
      true
    );
  }

  loginInProgress = true;

  try {

    showMessage("loginMsg", "Logging in...");

    await signInWithEmailAndPassword(
      auth,
      email,
      password
    );

  } catch (error) {

    console.error("LOGIN ERROR:", error);

    showMessage(
      "loginMsg",
      error.message,
      true
    );

  } finally {
    loginInProgress = false;
  }
});

on("logoutBtn", "click", async () => {

  try {
    await signOut(auth);
  } catch (error) {
    alert(error.message);
  }

});

onAuthStateChanged(auth, async user => {

  if (!user) {

    isAuthenticated = false;

    if ($("loginBox")) $("loginBox").hidden = false;
    if ($("adminPanel")) $("adminPanel").hidden = true;
    if ($("logoutBtn")) $("logoutBtn").hidden = true;

    return;
  }

  try {

    showMessage(
      "loginMsg",
      "Checking admin access..."
    );

    if (!await activeAdmin(user.uid)) {

      await signOut(auth);

      showMessage(
        "loginMsg",
        "Admin access not authorized.",
        true
      );

      return;
    }

    isAuthenticated = true;

    if ($("loginBox")) $("loginBox").hidden = true;
    if ($("adminPanel")) $("adminPanel").hidden = false;
    if ($("logoutBtn")) $("logoutBtn").hidden = false;

    await loadEverything();

  } catch (error) {

    console.error(error);

    showMessage(
      "loginMsg",
      "Data load error: " + error.message,
      true
    );

  }

});

// =====================================================
// NAVIGATION
// =====================================================

document.querySelectorAll(".admin-nav button")
  .forEach(button => {

    button.addEventListener("click", () => {

      document.querySelectorAll(".admin-section")
        .forEach(section => {
          section.hidden =
            section.id !== button.dataset.target;
        });

      document.querySelectorAll(".admin-nav button")
        .forEach(item => {
          item.classList.toggle(
            "active",
            item === button
          );
        });

    });

  });

// =====================================================
// CATEGORIES
// =====================================================

on("categoryForm", "submit", async event => {

  event.preventDefault();

  const id = value("categoryId");

  const data = {
    name: value("categoryName"),
    image: value("categoryImage"),
    active: $("categoryActive")?.checked ?? true,
    updatedAt: serverTimestamp()
  };

  try {

    if (id) {

      await updateDoc(
        doc(db, "categories", id),
        data
      );

    } else {

      data.createdAt = serverTimestamp();

      await addDoc(
        collection(db, "categories"),
        data
      );

    }

    $("categoryForm").reset();
    $("categoryId").value = "";

    await refreshCollections(["categories"]);

    showMessage(
      "categoryMsg",
      "Category saved successfully."
    );

  } catch (error) {

    showMessage(
      "categoryMsg",
      error.message,
      true
    );

  }

});

function renderCategories() {

  if (!$("categoryList")) return;

  $("categoryList").innerHTML = categories.map(x => `

    <article>
      <img
        src="${safeText(x.image)}"
        alt=""
        loading="lazy"
        decoding="async"
        onerror="this.style.display='none'"
      >

      <strong>${safeText(x.name)}</strong>

      <p>${x.active !== false ? "Active" : "Inactive"}</p>

      <button data-edit-category="${x.id}">
        Edit
      </button>

      <button data-delete-category="${x.id}">
        Delete
      </button>
    </article>

  `).join("");

  $("categoryList")
    .querySelectorAll("[data-edit-category]")
    .forEach(btn => {

      btn.addEventListener("click", () => {

        const x = categories.find(
          v => v.id === btn.dataset.editCategory
        );

        if (!x) return;

        $("categoryId").value = x.id;
        $("categoryName").value = x.name || "";
        $("categoryImage").value = x.image || "";

        $("categoryActive").checked =
          x.active !== false;

        preview(
          "categoryImage",
          "categoryPreview"
        );

      });

    });

  $("categoryList")
    .querySelectorAll("[data-delete-category]")
    .forEach(btn => {

      btn.addEventListener("click", async () => {

        const id = btn.dataset.deleteCategory;

        if (products.some(p => p.categoryId === id)) {
          return alert(
            "Move this category's products first."
          );
        }

        if (!confirm("Delete this category?")) return;

        try {

          await deleteDoc(
            doc(db, "categories", id)
          );

          await refreshCollections(["categories"]);

        } catch (error) {
          alert(error.message);
        }

      });

    });

}

on("clearCategory", "click", () => {

  $("categoryForm")?.reset();

  if ($("categoryId")) $("categoryId").value = "";

  if ($("categoryPreview")) {
    $("categoryPreview").hidden = true;
  }

});

// =====================================================
// BRANDS
// =====================================================

on("brandForm", "submit", async event => {

  event.preventDefault();

  const id = value("brandId");

  const data = {
    name: value("brandName"),
    logo: value("brandLogo"),
    active: $("brandActive")?.checked ?? true,
    updatedAt: serverTimestamp()
  };

  try {

    if (id) {

      await updateDoc(
        doc(db, "brands", id),
        data
      );

    } else {

      data.createdAt = serverTimestamp();

      await addDoc(
        collection(db, "brands"),
        data
      );

    }

    $("brandForm").reset();
    $("brandId").value = "";

    await refreshCollections(["brands"]);

    showMessage("brandMsg", "Brand saved.");

  } catch (error) {

    showMessage(
      "brandMsg",
      error.message,
      true
    );

  }

});

function renderBrands() {

  if (!$("brandList")) return;

  $("brandList").innerHTML = brands.map(x => `

    <article>

      <img
        src="${safeText(x.logo)}"
        alt=""
        loading="lazy"
        decoding="async"
        onerror="this.style.display='none'"
      >

      <strong>${safeText(x.name)}</strong>

      <p>${x.active !== false ? "Active" : "Inactive"}</p>

      <button data-edit-brand="${x.id}">
        Edit
      </button>

      <button data-delete-brand="${x.id}">
        Delete
      </button>

    </article>

  `).join("");

  $("brandList")
    .querySelectorAll("[data-edit-brand]")
    .forEach(btn => {

      btn.addEventListener("click", () => {

        const x = brands.find(
          v => v.id === btn.dataset.editBrand
        );

        if (!x) return;

        $("brandId").value = x.id;
        $("brandName").value = x.name || "";
        $("brandLogo").value = x.logo || "";

        $("brandActive").checked =
          x.active !== false;

        preview("brandLogo", "brandPreview");

      });

    });

  $("brandList")
    .querySelectorAll("[data-delete-brand]")
    .forEach(btn => {

      btn.addEventListener("click", async () => {

        const id = btn.dataset.deleteBrand;

        if (products.some(p => p.brandId === id)) {
          return alert(
            "Move this brand's products first."
          );
        }

        if (!confirm("Delete this brand?")) return;

        try {

          await deleteDoc(
            doc(db, "brands", id)
          );

          await refreshCollections(["brands"]);

        } catch (error) {
          alert(error.message);
        }

      });

    });

}

on("clearBrand", "click", () => {

  $("brandForm")?.reset();

  if ($("brandId")) $("brandId").value = "";

  if ($("brandPreview")) {
    $("brandPreview").hidden = true;
  }

});

// =====================================================
// QUANTITY PRICING
// =====================================================

function normalizeTier(tier) {

  return {
    minQuantity: Number(
      tier.minQuantity ?? tier.quantity ?? 0
    ),

    totalPrice: Number(
      tier.totalPrice ?? 0
    )
  };

}

function renderQuantityTiers() {

  const box = $("quantityPricingRows");

  if (!box) return;

  box.innerHTML = "";

  quantityTiers.forEach((tier, index) => {

    const row = document.createElement("div");

    row.style.cssText =
      "display:flex;gap:10px;margin-bottom:10px;flex-wrap:wrap";

    row.innerHTML = `

      <input
        type="number"
        min="1"
        step="1"
        placeholder="Minimum quantity"
        value="${safeText(tier.minQuantity)}"
        data-index="${index}"
        data-field="minQuantity"
      >

      <input
        type="number"
        min="0.01"
        step="0.01"
        placeholder="Total price for this tier"
        value="${safeText(tier.totalPrice)}"
        data-index="${index}"
        data-field="totalPrice"
      >

      <button type="button" data-remove="${index}">
        Remove
      </button>

    `;

    box.appendChild(row);

  });

}

on("addQuantityTier", "click", () => {

  quantityTiers.push({
    minQuantity: "",
    totalPrice: ""
  });

  renderQuantityTiers();

});

on("quantityPricingRows", "input", event => {

  const index = Number(event.target.dataset.index);
  const field = event.target.dataset.field;

  if (field && quantityTiers[index]) {
    quantityTiers[index][field] =
      event.target.value;
  }

});

on("quantityPricingRows", "click", event => {

  if (event.target.dataset.remove === undefined) return;

  quantityTiers.splice(
    Number(event.target.dataset.remove),
    1
  );

  renderQuantityTiers();

});

function getQuantityPricing() {

  const tiers = quantityTiers.map(normalizeTier);

  for (const tier of tiers) {

    if (
      !Number.isInteger(tier.minQuantity) ||
      tier.minQuantity < 1 ||
      !Number.isFinite(tier.totalPrice) ||
      tier.totalPrice <= 0
    ) {

      throw new Error(
        "Enter a valid minimum quantity and tier total price."
      );

    }

  }

  const quantities = tiers.map(
    tier => tier.minQuantity
  );

  if (new Set(quantities).size !== quantities.length) {
    throw new Error(
      "Duplicate tier quantities are not allowed."
    );
  }

  tiers.sort(
    (a, b) => a.minQuantity - b.minQuantity
  );

  for (let i = 1; i < tiers.length; i++) {

    const previousRate =
      tiers[i - 1].totalPrice /
      tiers[i - 1].minQuantity;

    const currentRate =
      tiers[i].totalPrice /
      tiers[i].minQuantity;

    if (currentRate > previousRate) {
      throw new Error(
        "Higher quantity tiers should not have a higher per-item rate."
      );
    }

  }

  return tiers;

}

export function calculateQuantityPrice(
  basePrice,
  requestedQuantity,
  savedTiers = []
) {

  const qty = Math.max(
    0,
    Math.floor(Number(requestedQuantity) || 0)
  );

  if (!qty) return 0;

  const tiers = (savedTiers || [])
    .map(normalizeTier)
    .filter(t =>
      t.minQuantity > 0 &&
      t.totalPrice > 0 &&
      t.minQuantity <= qty
    )
    .sort((a, b) =>
      a.minQuantity - b.minQuantity
    );

  if (!tiers.length) {
    return qty * Number(basePrice || 0);
  }

  const selected = tiers[tiers.length - 1];

  return qty * (
    selected.totalPrice /
    selected.minQuantity
  );

}

// =====================================================
// PRODUCTS
// =====================================================

let productSaving = false;

on("productForm", "submit", async event => {

  event.preventDefault();

  if (productSaving) return;

  const id = value("pid");
  const mrp = number("mrp");
  const price = number("price");
  const discount = number("productDiscount");

  if (!value("pname")) {
    return showMessage(
      "saveMsg",
      "Product name is required.",
      true
    );
  }

  if (
    mrp < 0 ||
    price < 0 ||
    price > mrp ||
    discount < 0
  ) {
    return showMessage(
      "saveMsg",
      "Check price and discount values.",
      true
    );
  }

  if (
    number("stock") < 0 ||
    number("purchaseCost") < 0 ||
    number("minStock") < 0
  ) {
    return showMessage(
      "saveMsg",
      "Negative values are not allowed.",
      true
    );
  }

  productSaving = true;

  try {

    const quantityPricing = getQuantityPricing();

    const data = {

      name: value("pname"),
      image: value("image"),
      description: value("description"),

      categoryId: value("productCategory"),
      brandId: value("productBrand"),

      unit: value("unit"),

      mrp,
      price,

      discountType: value("productDiscountType"),
      discountValue: discount,

      purchaseCost: number("purchaseCost"),
      stock: number("stock"),
      minStock: number("minStock"),

      active: $("active")?.checked ?? true,

      quantityPricing,

      updatedAt: serverTimestamp()

    };

    if (id) {

      await updateDoc(
        doc(db, "products", id),
        data
      );

    } else {

      data.createdAt = serverTimestamp();

      await addDoc(
        collection(db, "products"),
        data
      );

    }

    $("productForm").reset();

    $("pid").value = "";

    if ($("imagePreview")) {
      $("imagePreview").hidden = true;
    }

    quantityTiers = [];

    renderQuantityTiers();

    await refreshCollections(["products"]);

    showMessage(
      "saveMsg",
      "Product saved successfully."
    );

  } catch (error) {

    console.error(error);

    showMessage(
      "saveMsg",
      error.message,
      true
    );

  } finally {

    productSaving = false;

  }

});

// =====================================================
// SEARCH DEBOUNCE
// =====================================================

function debounce(fn, delay = 250) {

  let timer;

  return (...args) => {

    clearTimeout(timer);

    timer = setTimeout(() => {
      fn(...args);
    }, delay);

  };

}

// =====================================================
// RENDER PRODUCTS
// =====================================================

function renderProducts() {

  if (!$("productList")) return;

  const search = value("productSearch").toLowerCase();

  const filtered = products.filter(product =>
    String(product.name || "")
      .toLowerCase()
      .includes(search)
  );

  $("productList").innerHTML = filtered.map(p => {

    const tiers =
      (p.quantityPricing || []).length;

    return `

      <article>

        <img
          src="${safeText(p.image)}"
          alt=""
          loading="lazy"
          decoding="async"
          onerror="this.style.display='none'"
        >

        <strong>${safeText(p.name)}</strong>

        <p>MRP: ${money(p.mrp)}</p>
        <p>Sale: ${money(p.price)}</p>
        <p>Stock: ${Number(p.stock || 0)}</p>

        <p>
          ${p.active !== false ? "Active" : "Inactive"}
        </p>

        <p>Quantity Tiers: ${tiers}</p>

        <button data-edit-product="${p.id}">
          Edit
        </button>

        <button data-delete-product="${p.id}">
          Deactivate
        </button>

      </article>

    `;

  }).join("");

  $("productList")
    .querySelectorAll("[data-edit-product]")
    .forEach(btn => {

      btn.addEventListener("click", () => {

        const p = products.find(
          x => x.id === btn.dataset.editProduct
        );

        if (!p) return;

        $("pid").value = p.id;

        $("pname").value = p.name || "";
        $("image").value = p.image || "";
        $("description").value = p.description || "";

        $("productCategory").value =
          p.categoryId || "";

        $("productBrand").value =
          p.brandId || "";

        $("unit").value = p.unit || "";

        $("mrp").value =
          p.mrp ?? p.price ?? 0;

        $("price").value = p.price ?? 0;

        $("productDiscountType").value =
          p.discountType || "none";

        $("productDiscount").value =
          p.discountValue || 0;

        $("purchaseCost").value =
          p.purchaseCost || 0;

        $("stock").value = p.stock || 0;
        $("minStock").value = p.minStock || 0;

        $("active").checked =
          p.active !== false;

        quantityTiers =
          (p.quantityPricing || [])
            .map(normalizeTier);

        renderQuantityTiers();

        preview("image", "imagePreview");

        $("productForm").scrollIntoView({
          behavior: "smooth"
        });

      });

    });

  $("productList")
    .querySelectorAll("[data-delete-product]")
    .forEach(btn => {

      btn.addEventListener("click", async () => {

        if (!confirm("Deactivate this product?")) return;

        try {

          await updateDoc(
            doc(db, "products", btn.dataset.deleteProduct),
            {
              active: false,
              updatedAt: serverTimestamp()
            }
          );

          await refreshCollections(["products"]);

        } catch (error) {
          alert(error.message);
        }

      });

    });

}

on("productSearch", "input", debounce(renderProducts));

on("clear", "click", () => {

  $("productForm")?.reset();

  if ($("pid")) $("pid").value = "";

  if ($("imagePreview")) {
    $("imagePreview").hidden = true;
  }

  quantityTiers = [];

  renderQuantityTiers();

});

renderQuantityTiers();

// =====================================================
// SELECT DROPDOWNS
// =====================================================

function fillSelects() {

  if ($("productCategory")) {

    $("productCategory").innerHTML =
      '<option value="">Select Category</option>' +

      categories
        .filter(x => x.active !== false)
        .map(x => `
          <option value="${x.id}">
            ${safeText(x.name)}
          </option>
        `)
        .join("");

  }

  if ($("productBrand")) {

    $("productBrand").innerHTML =
      '<option value="">Select Brand</option>' +

      brands
        .filter(x => x.active !== false)
        .map(x => `
          <option value="${x.id}">
            ${safeText(x.name)}
          </option>
        `)
        .join("");

  }

  if ($("stockProduct")) {

    $("stockProduct").innerHTML =
      '<option value="">Select Product</option>' +

      products.map(x => `
        <option value="${x.id}">
          ${safeText(x.name)}
        </option>
      `).join("");

  }

}

// =====================================================
// INVENTORY MANAGEMENT
// =====================================================

let stockSaving = false;

on("stockForm", "submit", async event => {

  event.preventDefault();

  if (stockSaving) return;

  const productId = value("stockProduct");
  const qty = number("stockQuantity");
  const action = value("stockAction");
  const reason = value("stockReason");

  if (!productId || qty <= 0) {

    return showMessage(
      "stockMsg",
      "Select a product and enter a valid quantity.",
      true
    );

  }

  stockSaving = true;

  try {

    await runTransaction(db, async tx => {

      const ref = doc(
        db,
        "products",
        productId
      );

      const snap = await tx.get(ref);

      if (!snap.exists()) {
        throw new Error("Product not found.");
      }

      const p = snap.data();

      const oldStock = Number(p.stock || 0);

      let newStock = oldStock;

      if (action === "in") {
        newStock += qty;
      } else if (action === "out") {
        newStock -= qty;
      } else if (action === "adjust") {
        newStock = qty;
      } else {
        throw new Error("Invalid stock action.");
      }

      if (newStock < 0) {
        throw new Error("Stock cannot be negative.");
      }

      tx.update(ref, {
        stock: newStock,
        updatedAt: serverTimestamp()
      });

      const historyRef = doc(
        collection(db, "stockHistory")
      );

      tx.set(historyRef, {

        productId,
        productName: p.name || "",

        action,
        quantity: qty,

        oldStock,
        newStock,

        reason,

        createdAt: serverTimestamp()

      });

    });

    $("stockForm").reset();

    await refreshCollections([
      "products",
      "stockHistory"
    ]);

    showMessage(
      "stockMsg",
      "Stock updated successfully."
    );

  } catch (error) {

    showMessage(
      "stockMsg",
      error.message,
      true
    );

  } finally {

    stockSaving = false;

  }

});

function renderStock() {

  if (!$("stockList")) return;

  $("stockList").innerHTML = products.map(p => {

    const stock = Number(p.stock || 0);
    const minimum = Number(p.minStock || 0);

    return `

      <article>

        <strong>${safeText(p.name)}</strong>

        <p>Available: ${stock}</p>
        <p>Minimum: ${minimum}</p>

        <p>
          ${
            stock <= 0
              ? "OUT OF STOCK"
              : stock <= minimum
                ? "LOW STOCK"
                : "In Stock"
          }
        </p>

      </article>

    `;

  }).join("");

  const low = products.filter(p =>
    Number(p.stock || 0) > 0 &&
    Number(p.stock || 0) <= Number(p.minStock || 0)
  );

  const out = products.filter(p =>
    Number(p.stock || 0) <= 0
  );

  const inventoryValue = products.reduce(
    (sum, p) =>
      sum +
      Number(p.stock || 0) *
      Number(p.purchaseCost || 0),
    0
  );

  if ($("inventoryItemCount")) {
    $("inventoryItemCount").textContent =
      products.length;
  }

  if ($("inventoryLowStock")) {
    $("inventoryLowStock").textContent =
      low.length;
  }

  if ($("inventoryOutStock")) {
    $("inventoryOutStock").textContent =
      out.length;
  }

  if ($("inventoryValue")) {
    $("inventoryValue").textContent =
      money(inventoryValue);
  }

  if ($("inventoryProfit")) {
    const potential = products.reduce(
      (sum, p) =>
        sum +
        Number(p.stock || 0) *
        (
          Number(p.price || 0) -
          Number(p.purchaseCost || 0)
        ),
      0
    );

    $("inventoryProfit").textContent =
      money(potential);
  }

  if ($("lowStockProducts")) {
    $("lowStockProducts").textContent =
      low.length;
  }

}

function renderStockHistory() {

  if (!$("stockHistory")) return;

  $("stockHistory").innerHTML =
    stockHistory.map(x => `

      <article>

        <strong>${safeText(x.productName)}</strong>

        <p>Action: ${safeText(x.action)}</p>
        <p>Quantity: ${Number(x.quantity || 0)}</p>
        <p>Old Stock: ${Number(x.oldStock || 0)}</p>
        <p>New Stock: ${Number(x.newStock || 0)}</p>
        <p>Reason: ${safeText(x.reason)}</p>
        <p>Date: ${dateString(x.createdAt)}</p>

      </article>

    `).join("");

}

// =====================================================
// SUPPLIERS
// =====================================================

on("supplierForm", "submit", async event => {

  event.preventDefault();

  const id = value("supplierId");

  const data = {

    name: value("supplierName"),
    phone: value("supplierPhone"),
    address: value("supplierAddress"),
    notes: value("supplierNotes"),

    updatedAt: serverTimestamp()

  };

  try {

    if (id) {

      await updateDoc(
        doc(db, "suppliers", id),
        data
      );

    } else {

      data.createdAt = serverTimestamp();

      await addDoc(
        collection(db, "suppliers"),
        data
      );

    }

    $("supplierForm").reset();
    $("supplierId").value = "";

    await refreshCollections(["suppliers"]);

    showMessage(
      "supplierMsg",
      "Supplier saved."
    );

  } catch (error) {

    showMessage(
      "supplierMsg",
      error.message,
      true
    );

  }

});

function renderSuppliers() {

  if (!$("supplierList")) return;

  $("supplierList").innerHTML =
    suppliers.map(s => `

      <article>

        <strong>${safeText(s.name)}</strong>

        <p>${safeText(s.phone)}</p>
        <p>${safeText(s.address)}</p>

        <button data-edit-supplier="${s.id}">
          Edit
        </button>

      </article>

    `).join("");

  $("supplierList")
    .querySelectorAll("[data-edit-supplier]")
    .forEach(btn => {

      btn.addEventListener("click", () => {

        const s = suppliers.find(
          x => x.id === btn.dataset.editSupplier
        );

        if (!s) return;

        $("supplierId").value = s.id;
        $("supplierName").value = s.name || "";
        $("supplierPhone").value = s.phone || "";
        $("supplierAddress").value = s.address || "";
        $("supplierNotes").value = s.notes || "";

      });

    });

}

on("clearSupplier", "click", () => {

  $("supplierForm")?.reset();

  if ($("supplierId")) {
    $("supplierId").value = "";
  }

});

// =====================================================
// EXPENSE MANAGEMENT
// =====================================================

on("expenseForm", "submit", async event => {

  event.preventDefault();

  const id = value("expenseId");
  const amount = number("expenseAmount");

  if (amount <= 0) {

    return showMessage(
      "expenseMsg",
      "Enter a valid amount.",
      true
    );

  }

  const data = {

    category: value("expenseCategory"),
    description: value("expenseDescription"),

    amount,

    date: value("expenseDate"),

    paymentMethod: value("expensePaymentMethod"),

    updatedAt: serverTimestamp()

  };

  try {

    if (id) {

      await updateDoc(
        doc(db, "expenses", id),
        data
      );

    } else {

      data.createdAt = serverTimestamp();

      await addDoc(
        collection(db, "expenses"),
        data
      );

    }

    $("expenseForm").reset();
    $("expenseId").value = "";

    await refreshCollections(["expenses"]);

    showMessage(
      "expenseMsg",
      "Expense saved."
    );

  } catch (error) {

    showMessage(
      "expenseMsg",
      error.message,
      true
    );

  }

});

function renderExpenses() {

  if (!$("expenseList")) return;

  const from = value("expenseFrom");
  const to = value("expenseTo");

  const filtered = expenses.filter(e =>
    (!from || e.date >= from) &&
    (!to || e.date <= to)
  );

  const total = filtered.reduce(
    (sum, e) => sum + Number(e.amount || 0),
    0
  );

  if ($("expenseTotal")) {
    $("expenseTotal").textContent =
      "Total Expenses: " + money(total);
  }

  $("expenseList").innerHTML =
    filtered.map(e => `

      <article>

        <strong>${safeText(e.category)}</strong>

        <p>${safeText(e.description)}</p>
        <p>Amount: ${money(e.amount)}</p>
        <p>Date: ${safeText(e.date)}</p>
        <p>Payment: ${safeText(e.paymentMethod)}</p>

        <button data-edit-expense="${e.id}">
          Edit
        </button>

        <button data-delete-expense="${e.id}">
          Delete
        </button>

      </article>

    `).join("");

  $("expenseList")
    .querySelectorAll("[data-edit-expense]")
    .forEach(btn => {

      btn.addEventListener("click", () => {

        const e = expenses.find(
          x => x.id === btn.dataset.editExpense
        );

        if (!e) return;

        $("expenseId").value = e.id;
        $("expenseCategory").value = e.category || "";
        $("expenseDescription").value =
          e.description || "";

        $("expenseAmount").value = e.amount || 0;
        $("expenseDate").value = e.date || "";

        $("expensePaymentMethod").value =
          e.paymentMethod || "Cash";

      });

    });

  $("expenseList")
    .querySelectorAll("[data-delete-expense]")
    .forEach(btn => {

      btn.addEventListener("click", async () => {

        if (!confirm("Delete this expense?")) return;

        try {

          await deleteDoc(
            doc(db, "expenses", btn.dataset.deleteExpense)
          );

          await refreshCollections(["expenses"]);

        } catch (error) {
          alert(error.message);
        }

      });

    });

}

on("clearExpense", "click", () => {

  $("expenseForm")?.reset();

  if ($("expenseId")) {
    $("expenseId").value = "";
  }

});

on("filterExpenses", "click", renderExpenses);

// =====================================================
// ORDERS
// =====================================================

function getOrderItems(order) {

  return order.items ||
    order.products ||
    order.orderItems ||
    [];

}

function renderOrders() {

  if (!$("orderList")) return;

  const filter = value("orderFilter");

  const filtered = orders.filter(order =>

    filter === "all" ||
    !filter ||
    String(order.status || "pending").toLowerCase() === filter

  );

  $("orderList").innerHTML =
    filtered.map(o => `

      <article>

        <strong>Order: ${safeText(o.id)}</strong>

        <p>
          Customer:
          ${safeText(o.customerName || o.name)}
        </p>

        <p>
          Phone:
          ${safeText(o.phone || o.customerPhone)}
        </p>

        <p>
          Total:
          ${money(
            o.total ||
            o.grandTotal ||
            o.totalAmount ||
            0
          )}
        </p>

        <p>
          Status:
          ${safeText(o.status || "pending")}
        </p>

        <button data-view-order="${o.id}">
          View / Print Bill
        </button>

        <select data-status-order="${o.id}">

          ${
            [
              "pending",
              "accepted",
              "processing",
              "shipped",
              "delivered",
              "cancelled"
            ].map(status => `

              <option
                value="${status}"
                ${
                  String(o.status || "pending").toLowerCase()
                  === status
                    ? "selected"
                    : ""
                }
              >
                ${status}
              </option>

            `).join("")
          }

        </select>

      </article>

    `).join("");

  $("orderList")
    .querySelectorAll("[data-view-order]")
    .forEach(button => {

      button.addEventListener("click", () => {
        openBill(button.dataset.viewOrder);
      });

    });

  $("orderList")
    .querySelectorAll("[data-status-order]")
    .forEach(select => {

      select.addEventListener("change", async () => {

        select.disabled = true;

        try {

          await updateDoc(
            doc(db, "orders", select.dataset.statusOrder),
            {
              status: select.value,
              updatedAt: serverTimestamp()
            }
          );

          await refreshCollections(["orders"]);

        } catch (error) {

          alert(error.message);

        } finally {

          select.disabled = false;

        }

      });

    });

}

on("orderFilter", "change", renderOrders);

// =====================================================
// BILL SYSTEM
// =====================================================

const itemDiscount = item =>
  Number(item.discount || 0) *
  Number(item.quantity || 1);

function billNumbers(
  order,
  orderDiscountType = "none",
  orderDiscountValue = 0
) {

  const items = getOrderItems(order);

  const subtotal = items.reduce((sum, item) =>

    sum + Number(
      item.lineSubtotal ??
      (
        Number(item.price ?? item.salePrice ?? 0) *
        Number(item.quantity || 1)
      )
    ),

    0

  );

  const productDiscount = items.reduce(
    (sum, item) =>
      sum + Number(
        item.discountTotal ?? itemDiscount(item)
      ),
    0
  );

  let discount = 0;

  if (orderDiscountType === "percentage") {

    discount =
      subtotal *
      Number(orderDiscountValue || 0) /
      100;

  }

  if (orderDiscountType === "fixed") {

    discount =
      Number(orderDiscountValue || 0);

  }

  discount = Math.min(
    Math.max(0, discount),
    Math.max(0, subtotal - productDiscount)
  );

  const delivery = Number(
    order.deliveryFee ??
    order.deliveryCharge ??
    0
  );

  return {

    subtotal,
    productDiscount,
    orderDiscount: discount,
    delivery,

    total: Math.max(
      0,
      subtotal -
      productDiscount -
      discount
    ) + delivery

  };

}

function openBill(id) {

  const order = orders.find(o => o.id === id);

  if (!order) return;

  selectedBill = order;

  window.sastagoSelectedBill = order;

  $("billArea").hidden = false;

  $("billOrderId").textContent = order.id;

  $("billDate").textContent =
    dateString(order.createdAt);

  $("billCustomer").textContent =
    order.customerName || order.name || "";

  $("billPhone").textContent =
    order.phone || order.customerPhone || "";

  $("billAddress").textContent =
    order.address || "";

  const items = getOrderItems(order);

  const totals = billNumbers(order);

  $("billItems").innerHTML =
    items.map(item => {

      const qty = Number(item.quantity || 1);

      const price = Number(
        item.price ?? item.salePrice ?? 0
      );

      const lineSubtotal = Number(
        item.lineSubtotal ?? price * qty
      );

      const discount = Number(
        item.discountTotal ?? itemDiscount(item)
      );

      return `

        <div>

          <p>
            <strong>
              ${safeText(item.name || item.productName)}
            </strong>
          </p>

          <p>${qty} x ${money(price)}</p>

          <p>Discount: ${money(discount)}</p>

          <p>
            Total:
            ${money(
              Math.max(0, lineSubtotal - discount)
            )}
          </p>

        </div>

      `;

    }).join("");

  $("billSubtotal").textContent =
    money(totals.subtotal);

  $("billProductDiscount").textContent =
    money(totals.productDiscount);

  $("billDiscountType").value = "none";
  $("billDiscountValue").value = 0;

  $("billTotalDiscount").textContent =
    money(totals.productDiscount);

  $("billGrandTotal").textContent =
    money(totals.total);

  window.sastagoBillTotals = totals;

  $("billArea").scrollIntoView({
    behavior: "smooth"
  });

}

on("applyBillDiscount", "click", () => {

  if (!selectedBill) return;

  const totals = billNumbers(
    selectedBill,
    value("billDiscountType"),
    number("billDiscountValue")
  );

  $("billTotalDiscount").textContent =
    money(
      totals.productDiscount +
      totals.orderDiscount
    );

  $("billGrandTotal").textContent =
    money(totals.total);

  window.sastagoBillTotals = totals;

});

on("printBillBtn", "click", () => {

  if (selectedBill) {
    window.print();
  }

});

on("closeBillBtn", "click", () => {

  $("billArea").hidden = true;

  selectedBill = null;

  window.sastagoSelectedBill = null;

});

// =====================================================
// CUSTOMERS
// =====================================================

function renderCustomers() {

  if (!$("customerList")) return;

  const q = value("customerSearch").toLowerCase();

  const filtered = customers.filter(c =>

    String(c.name || "").toLowerCase().includes(q) ||

    String(c.phone || "").toLowerCase().includes(q)

  );

  $("customerList").innerHTML =
    filtered.map(c => `

      <article>

        <strong>${safeText(c.name)}</strong>

        <p>Phone: ${safeText(c.phone)}</p>
        <p>Email: ${safeText(c.email)}</p>
        <p>Address: ${safeText(c.address)}</p>

      </article>

    `).join("");

}

on(
  "customerSearch",
  "input",
  debounce(renderCustomers)
);

// =====================================================
// DASHBOARD AND REPORTS
// =====================================================

const orderTotal = order =>
  Number(
    order.total ??
    order.grandTotal ??
    order.totalAmount ??
    0
  );

const completedOrders = () =>

  orders.filter(order =>

    ["delivered", "completed"].includes(
      String(order.status || "").toLowerCase()
    )

  );

const calculateOrderCost = order =>

  getOrderItems(order).reduce(

    (sum, item) =>

      sum +
      Number(item.purchaseCost || 0) *
      Number(item.quantity || 1),

    0

  );

function renderDashboard() {

  const set = (id, val) => {

    if ($(id)) {
      $(id).textContent = val;
    }

  };

  set("totalProducts", products.length);
  set("totalCategories", categories.length);
  set("totalBrands", brands.length);
  set("totalOrders", orders.length);
  set("totalCustomers", customers.length);

  const done = completedOrders();

  const sales = done.reduce(
    (sum, order) =>
      sum + orderTotal(order),
    0
  );

  const exp = expenses.reduce(
    (sum, expense) =>
      sum + Number(expense.amount || 0),
    0
  );

  const cost = done.reduce(
    (sum, order) =>
      sum + calculateOrderCost(order),
    0
  );

  set("totalSales", money(sales));
  set("totalExpenses", money(exp));
  set("totalProfit", money(sales - cost - exp));

  set(
    "pendingOrders",
    orders.filter(order =>
      ["pending", "received"].includes(
        String(order.status || "pending").toLowerCase()
      )
    ).length
  );

}

function renderReports() {

  const done = completedOrders();

  const sales = done.reduce(
    (sum, order) =>
      sum + orderTotal(order),
    0
  );

  const costs = done.reduce(
    (sum, order) =>
      sum + calculateOrderCost(order),
    0
  );

  const exp = expenses.reduce(
    (sum, expense) =>
      sum + Number(expense.amount || 0),
    0
  );

  const now = new Date();

  const today = [
    now.getFullYear(),
    String(now.getMonth() + 1).padStart(2, "0"),
    String(now.getDate()).padStart(2, "0")
  ].join("-");

  const daily = done.filter(order => {

    const d = order.createdAt?.toDate
      ? order.createdAt.toDate()
      : new Date(order.createdAt || 0);

    if (Number.isNaN(d.getTime())) return false;

    const date = [
      d.getFullYear(),
      String(d.getMonth() + 1).padStart(2, "0"),
      String(d.getDate()).padStart(2, "0")
    ].join("-");

    return date === today;

  }).reduce(
    (sum, order) =>
      sum + orderTotal(order),
    0
  );

  const monthly = done.filter(order => {

    const d = order.createdAt?.toDate
      ? order.createdAt.toDate()
      : new Date(order.createdAt || 0);

    return (
      !Number.isNaN(d.getTime()) &&
      d.getFullYear() === now.getFullYear() &&
      d.getMonth() === now.getMonth()
    );

  }).reduce(
    (sum, order) =>
      sum + orderTotal(order),
    0
  );

  const set = (id, val) => {

    if ($(id)) {
      $(id).textContent = val;
    }

  };

  set("dailySales", money(daily));
  set("monthlySales", money(monthly));
  set("totalCost", money(costs));
  set("reportExpenses", money(exp));
  set("netProfit", money(sales - costs - exp));

}

on("refreshReports", "click", renderReports);

// =====================================================
// REPORT EXPORTS
// =====================================================

function reportRows() {

  const type = value("exportReportType");

  if (type === "products") return products;

  if (type === "inventory") {

    return products.map(p => ({
      name: p.name,
      stock: p.stock,
      minStock: p.minStock,
      purchaseCost: p.purchaseCost
    }));

  }

  if (type === "lowstock") {

    return products.filter(p =>
      Number(p.stock || 0) > 0 &&
      Number(p.stock || 0) <= Number(p.minStock || 0)
    );

  }

  if (type === "outstock") {

    return products.filter(p =>
      Number(p.stock || 0) <= 0
    );

  }

  if (type === "orders") return orders;

  if (type === "customers") return customers;

  if (type === "expenses") return expenses;

  if (type === "stock") return stockHistory;

  if (type === "purchases") {

    return stockHistory.filter(
      x => x.action === "in"
    );

  }

  if (type === "discounts") {

    return orders.map(o => ({
      orderId: o.id,
      discount: o.discount || 0,
      total: orderTotal(o)
    }));

  }

  if (type === "sales") {

    return completedOrders().map(o => ({
      orderId: o.id,
      date: dateString(o.createdAt),
      total: orderTotal(o),
      status: o.status
    }));

  }

  if (type === "profit") {

    return [{
      sales: completedOrders().reduce(
        (sum, order) =>
          sum + orderTotal(order),
        0
      ),

      cost: completedOrders().reduce(
        (sum, order) =>
          sum + calculateOrderCost(order),
        0
      ),

      expenses: expenses.reduce(
        (sum, expense) =>
          sum + Number(expense.amount || 0),
        0
      )

    }];

  }

  return [];

}

function downloadFile(content, filename, type) {

  const blob = new Blob([content], { type });

  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");

  a.href = url;
  a.download = filename;

  document.body.appendChild(a);
  a.click();
  a.remove();

  setTimeout(() => {
    URL.revokeObjectURL(url);
  }, 1500);

}

function exportCSV() {

  const rows = reportRows();

  if (!rows.length) {

    return showMessage(
      "reportMsg",
      "No data available to export.",
      true
    );

  }

  const headers = [
    ...new Set(
      rows.flatMap(row => Object.keys(row))
    )
  ];

  const csv = [

    headers.join(","),

    ...rows.map(row =>

      headers.map(key => {

        let v = row[key];

        if (v?.toDate) {
          v = v.toDate().toISOString();
        }

        if (v && typeof v === "object") {
          v = JSON.stringify(v);
        }

        return '"' +
          String(v ?? "").replace(/"/g, '""') +
          '"';

      }).join(",")

    )

  ].join("\n");

  downloadFile(
    "\uFEFF" + csv,
    "sastago-" + value("exportReportType") + ".csv",
    "text/csv;charset=utf-8;"
  );

  showMessage(
    "reportMsg",
    "CSV export ready."
  );

}

on("exportCsvBtn", "click", exportCSV);

// EXCEL EXPORT

on("exportExcelBtn", "click", async () => {

  try {

    const rows = reportRows();

    if (!rows.length) {

      return showMessage(
        "reportMsg",
        "No data available.",
        true
      );

    }

    const { utils, writeFile } =
      await import(
        "https://cdn.jsdelivr.net/npm/xlsx@0.18.5/+esm"
      );

    const ws = utils.json_to_sheet(rows);

    const wb = utils.book_new();

    utils.book_append_sheet(
      wb,
      ws,
      "Report"
    );

    writeFile(
      wb,
      "sastago-" +
      value("exportReportType") +
      ".xlsx"
    );

    showMessage(
      "reportMsg",
      "Excel report downloaded."
    );

  } catch (error) {

    showMessage(
      "reportMsg",
      error.message,
      true
    );

  }

});

// PDF EXPORT

on("exportPdfBtn", "click", async () => {

  try {

    const rows = reportRows();

    if (!rows.length) {

      return showMessage(
        "reportMsg",
        "No data available.",
        true
      );

    }

    const { jsPDF } =
      await import(
        "https://cdn.jsdelivr.net/npm/jspdf@2.5.2/+esm"
      );

    const pdf = new jsPDF();

    pdf.setFontSize(16);

    pdf.text(
      "SastaGo " +
      value("exportReportType") +
      " Report",
      14,
      18
    );

    let y = 30;

    rows.forEach(row => {

      const line = Object.entries(row)
        .map(([key, val]) =>
          key + ": " +
          (
            val?.toDate
              ? dateString(val)
              : String(val ?? "")
          )
        )
        .join(" | ");

      const wrapped =
        pdf.splitTextToSize(line, 180);

      if (y + wrapped.length * 6 > 280) {

        pdf.addPage();

        y = 15;

      }

      pdf.text(wrapped, 14, y);

      y += wrapped.length * 6 + 4;

    });

    pdf.save(
      "sastago-" +
      value("exportReportType") +
      ".pdf"
    );

    showMessage(
      "reportMsg",
      "PDF report downloaded."
    );

  } catch (error) {

    showMessage(
      "reportMsg",
      error.message,
      true
    );

  }

});

// =====================================================
// IMAGE PREVIEWS
// =====================================================

function preview(inputId, imageId) {

  const url = value(inputId);
  const img = $(imageId);

  if (!img) return;

  if (!url) {
    img.hidden = true;
    return;
  }

  img.src = url;
  img.hidden = false;

  img.onerror = () => {
    img.hidden = true;
  };

}

[
  ["image", "imagePreview"],
  ["categoryImage", "categoryPreview"],
  ["brandLogo", "brandPreview"]
].forEach(([inputId, imageId]) => {

  on(inputId, "input", () => {
    preview(inputId, imageId);
  });

});

// =====================================================
// MANUAL REFRESH
// =====================================================

on("refreshDataBtn", "click", async () => {

  const button = $("refreshDataBtn");

  if (button) button.disabled = true;

  try {

    await loadEverything();

    showMessage(
      "reportMsg",
      "Data refreshed successfully."
    );

  } catch (error) {

    alert(error.message);

  } finally {

    if (button) button.disabled = false;

  }

});

// =====================================================
// BILL TOOLS COMPATIBILITY
// =====================================================

window.sastagoSelectedBill = null;
window.sastagoBillTotals = null;

window.sastagoOpenBill = openBill;

// =====================================================
// SECURITY REMINDER
// =====================================================
//
// Admin UI checks are not a replacement for Firestore
// Security Rules.
//
// Protect admin collections so only authenticated users
// with admins/{uid}.active === true can access them.
//
// =====================================================
// END OF SASTAGO ADMIN JAVASCRIPT
// =====================================================