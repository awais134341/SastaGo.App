#!/usr/bin/env bash
set -euo pipefail

# Run from Customer-App after npm install. Bundles Capacitor bare imports so
# Android WebView does not encounter unresolved package specifiers.
npx esbuild customer.js --bundle --format=esm --platform=browser --target=es2020 --external:https://* --outfile=customer.bundle.js
npx esbuild customer-location.js --bundle --format=esm --platform=browser --target=es2020 --outfile=customer-location.bundle.js
npx esbuild customer-bill-tools.js --bundle --format=esm --platform=browser --target=es2020 --outfile=customer-bill-tools.bundle.js

python3 - <<'PY'
from pathlib import Path
replacements = {
    'src="customer.js"': 'src="customer.bundle.js"',
    'src="./customer.js"': 'src="./customer.bundle.js"',
    'src="customer-location.js"': 'src="customer-location.bundle.js"',
    'src="./customer-location.js"': 'src="./customer-location.bundle.js"',
    'src="customer-bill-tools.js"': 'src="customer-bill-tools.bundle.js"',
    'src="./customer-bill-tools.js"': 'src="./customer-bill-tools.bundle.js"',
}
for name in ("customer.html", "product.html"):
    p = Path(name)
    html = p.read_text()
    for old, new in replacements.items():
        html = html.replace(old, new)
    p.write_text(html)
for name in ("customer.bundle.js", "customer-location.bundle.js", "customer-bill-tools.bundle.js"):
    p = Path(name)
    if not p.exists() or p.stat().st_size == 0:
        raise SystemExit(f"Build failed: {name} missing or empty")
PY

echo 'SastaGo customer web bundles created successfully.'
