const APP_CONFIG = {
  name: "SastaGo Admin",
  shortName: "SastaGo Admin",
  appType: "admin",
  startPage: "./admin.html",
  icon: "./app-icons/admin-icon.png/admin-icon.png"
};

export default APP_CONFIG;
