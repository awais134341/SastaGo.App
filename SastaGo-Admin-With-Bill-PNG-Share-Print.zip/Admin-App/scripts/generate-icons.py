from PIL import Image
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

SOURCE = ROOT / "app-icons" / "icon.png"

ANDROID_RES = ROOT / "android" / "app" / "src" / "main" / "res"

SIZES = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}

def main():
    if not SOURCE.exists():
        raise FileNotFoundError(
            f"Icon not found: {SOURCE}"
        )

    icon = Image.open(SOURCE).convert("RGBA")

    if icon.width != icon.height:
        raise ValueError("Icon must be square (1:1).")

    for folder, size in SIZES.items():
        output_dir = ANDROID_RES / folder
        output_dir.mkdir(parents=True, exist_ok=True)

        resized = icon.resize(
            (size, size),
            Image.Resampling.LANCZOS
        )

        resized.save(output_dir / "ic_launcher.png")
        resized.save(output_dir / "ic_launcher_round.png")

        print(f"Created {folder}: {size}x{size}")

    print("SastaGo App Icons generated successfully!")

if __name__ == "__main__":
    main()