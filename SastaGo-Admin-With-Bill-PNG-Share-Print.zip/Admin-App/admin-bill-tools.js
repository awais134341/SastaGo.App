import { Capacitor } from "@capacitor/core";
import { FileSharer } from "@capgo/capacitor-file-sharer";
import { Printer } from "@capgo/capacitor-printer";

/* =====================================================
   SASTAGO ADMIN BILL TOOLS
   ANDROID ONLY
   GALLERY SAVE / SHARE / MOBILE PRINT
   FUTURE BLUETOOTH PRINTER BRIDGE
   ===================================================== */

(() => {
  "use strict";

  const W = 384;
  const WA = "03060965926";

  const el = id => document.getElementById(id);

  const num = v => {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  };

  const val = (v, d = "-") =>
    v == null || String(v).trim() === ""
      ? d
      : String(v).trim();

  const money = n =>
    "Rs. " + num(n).toLocaleString("en-PK", {
      maximumFractionDigits: 2
    });

  /* ANDROID / CAPACITOR DETECTION */

  function isAndroidApp() {
    return Capacitor.isNativePlatform() && Capacitor.getPlatform() === "android";
  }

  function requireAndroid() {
    if (!isAndroidApp()) {
      throw new Error("Yeh feature sirf SastaGo Android app mein available hai.");
    }
  }

  function nativeBridge() {
    return window.SastaGoNative || null;
  }

  function notify(message) {
    if (window.sastagoShowToast) {
      window.sastagoShowToast(message);
    } else {
      alert(message);
    }
  }

  function orderNow() {
    const order = window.sastagoSelectedBill;

    if (!order) {
      notify("Please open an order bill first.");
      return null;
    }

    return order;
  }

  function itemsOf(order) {
    const items =
      order.items ||
      order.products ||
      order.orderItems ||
      [];

    return Array.isArray(items) ? items : [];
  }

  function totalsOf(order) {
    const items = itemsOf(order);

    const subtotal = items.reduce((sum, item) => {
      const qty = num(item.quantity ?? item.qty ?? 1);

      const price = num(
        item.price ??
        item.unitPrice ??
        item.salePrice
      );

      return sum + num(
        item.lineSubtotal ??
        item.subtotal ??
        price * qty
      );
    }, 0);

    const shared = window.sastagoBillTotals;

    if (shared) {
      return {
        subtotal: num(shared.subtotal),
        productDiscount: num(shared.productDiscount),
        extraDiscount: num(shared.orderDiscount),
        delivery: num(shared.delivery),
        service: num(shared.service),
        grand: num(shared.total)
      };
    }

    const productDiscount = num(
      order.productDiscount ?? order.itemsDiscount
    );

    const type =
      el("billDiscountType")?.value || "none";

    const discountValue = num(
      el("billDiscountValue")?.value
    );

    let extraDiscount = 0;

    if (
      type === "percentage" ||
      type === "percent"
    ) {
      extraDiscount =
        subtotal * Math.max(0, discountValue) / 100;
    }

    if (
      type === "fixed" ||
      type === "amount"
    ) {
      extraDiscount = Math.max(0, discountValue);
    }

    extraDiscount = Math.min(
      extraDiscount,
      Math.max(0, subtotal - productDiscount)
    );

    const delivery = num(
      order.deliveryFee ??
      order.deliveryCharge ??
      order.deliveryCharges ??
      order.shippingFee
    );

    const service = num(
      order.serviceCharge ?? order.serviceFee
    );

    return {
      subtotal,
      productDiscount,
      extraDiscount,
      delivery,
      service,
      grand: Math.max(
        0,
        subtotal -
        productDiscount -
        extraDiscount +
        delivery +
        service
      )
    };
  }

  function dateOf(order) {
    const d = order.createdAt?.toDate
      ? order.createdAt.toDate()
      : order.createdAt?.seconds
        ? new Date(order.createdAt.seconds * 1000)
        : order.createdAt
          ? new Date(order.createdAt)
          : new Date();

    return Number.isNaN(d.getTime())
      ? new Date().toLocaleString()
      : d.toLocaleString();
  }

  function wrap(ctx, text, width) {
    const lines = [];
    let line = "";

    String(text).split(/\s+/).forEach(word => {
      const test = line
        ? line + " " + word
        : word;

      if (
        ctx.measureText(test).width > width &&
        line
      ) {
        lines.push(line);
        line = word;
      } else {
        line = test;
      }
    });

    if (line) lines.push(line);

    return lines;
  }

  /* BILL CANVAS */

  function createCanvas(order) {
    const items = itemsOf(order);
    const totals = totalsOf(order);

    const customer = val(
      order.customerName ?? order.name
    );

    const phone = val(
      order.customerPhone ?? order.phone
    );

    const address = val(
      order.deliveryAddress ?? order.address,
      ""
    );

    const city = val(order.city, "");

    const email = val(
      order.customerEmail ?? order.email,
      ""
    );

    const payment = val(
      order.paymentMethod ?? order.payment,
      ""
    );

    const map = val(
      order.mapLink ?? order.mapsUrl,
      ""
    );

    const orderNo = val(
      order.orderNumber ??
      order.id ??
      order.orderId
    );

    const measure = document
      .createElement("canvas")
      .getContext("2d");

    measure.font = "14px Arial";

    let estimatedHeight = 500;

    if (address) {
      estimatedHeight +=
        wrap(measure, address, 340).length * 20;
    }

    items.forEach(item => {
      const name = val(
        item.name ?? item.productName,
        "Product"
      );

      estimatedHeight +=
        55 + wrap(measure, name, 340).length * 18;
    });

    estimatedHeight += 100;

    const canvas = document.createElement("canvas");

    canvas.width = W;
    canvas.height = estimatedHeight;

    const ctx = canvas.getContext("2d");

    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, W, estimatedHeight);

    let y = 34;

    const center = (
      text,
      size = 15,
      bold = false
    ) => {
      ctx.font =
        `${bold ? "bold " : ""}${size}px Arial`;

      ctx.fillStyle = "#111";
      ctx.textAlign = "center";

      ctx.fillText(String(text), W / 2, y);

      y += size + 8;
    };

    const row = (label, value, bold = false) => {
      ctx.font =
        `${bold ? "bold " : ""}14px Arial`;

      ctx.fillStyle = "#111";

      ctx.textAlign = "left";
      ctx.fillText(label, 18, y);

      ctx.textAlign = "right";
      ctx.fillText(value, W - 18, y);

      y += 23;
    };

    const detail = (label, value) => {
      if (!value) return;

      ctx.font = "13px Arial";
      ctx.textAlign = "left";
      ctx.fillStyle = "#111";

      const lines = wrap(
        ctx,
        `${label}: ${value}`,
        340
      );

      lines.forEach(line => {
        ctx.fillText(line, 18, y);
        y += 19;
      });
    };

    const rule = () => {
      ctx.beginPath();

      ctx.setLineDash([4, 4]);

      ctx.moveTo(18, y);
      ctx.lineTo(W - 18, y);

      ctx.strokeStyle = "#555";
      ctx.stroke();

      ctx.setLineDash([]);

      y += 14;
    };

    center("SastaGo", 27, true);
    center("Har Cheez, Aap Ke Qareeb!", 13);
    center("ORDER BILL", 18, true);

    rule();

    detail("Order", orderNo);
    detail("Date", dateOf(order));
    detail("Status", val(order.status, "Pending"));

    rule();

    detail("Customer", customer);
    detail("Phone", phone);
    detail("City", city);
    detail("Address", address);
    detail("Email", email);
    detail("Payment", payment);

    if (map) detail("Map", map);

    rule();

    ctx.font = "bold 13px Arial";
    ctx.textAlign = "left";

    ctx.fillText("ITEM", 18, y);

    ctx.textAlign = "right";
    ctx.fillText("AMOUNT", W - 18, y);

    y += 23;

    items.forEach(item => {
      const name = val(
        item.name ?? item.productName,
        "Product"
      );

      const qty = num(
        item.quantity ?? item.qty ?? 1
      );

      const price = num(
        item.price ??
        item.unitPrice ??
        item.salePrice
      );

      const amount = num(
        item.lineSubtotal ??
        item.subtotal ??
        price * qty
      );

      ctx.font = "bold 13px Arial";
      ctx.textAlign = "left";

      wrap(ctx, name, 340).forEach(line => {
        ctx.fillText(line, 18, y);
        y += 18;
      });

      ctx.font = "12px Arial";
      ctx.textAlign = "left";

      ctx.fillText(
        `${qty} x ${money(price)}`,
        18,
        y
      );

      ctx.textAlign = "right";

      ctx.fillText(
        money(amount),
        W - 18,
        y
      );

      y += 25;
    });

    rule();

    row("Subtotal", money(totals.subtotal));

    if (totals.productDiscount) {
      row(
        "Product Discount",
        "-" + money(totals.productDiscount)
      );
    }

    if (totals.extraDiscount) {
      row(
        "Order Discount",
        "-" + money(totals.extraDiscount)
      );
    }

    row("Delivery Fee", money(totals.delivery));
    row("Service Charge", money(totals.service));

    rule();

    row("GRAND TOTAL", money(totals.grand), true);

    y += 10;

    center(
      "Thank you for shopping with SastaGo!",
      13,
      true
    );

    center("WhatsApp: " + WA, 13);

    center(
      "Please keep this bill for your records.",
      11
    );

    const finalCanvas =
      document.createElement("canvas");

    finalCanvas.width = W;
    finalCanvas.height = y + 20;

    finalCanvas
      .getContext("2d")
      .drawImage(canvas, 0, 0);

    return finalCanvas;
  }

  function filename(order) {
    const id = val(
      order.orderNumber ??
      order.id ??
      order.orderId,
      "Order"
    );

    return (
      "SastaGo-" +
      id.replace(/[^a-z0-9_-]/gi, "-") +
      ".png"
    );
  }

  function blobOf(canvas) {
    if (!canvas || !canvas.width || !canvas.height) {
      return Promise.reject(new Error("Bill image is empty. Please reopen the bill."));
    }
    return new Promise((resolve, reject) => {
      if (typeof canvas.toBlob !== "function") {
        reject(new Error("This device cannot create a PNG image."));
        return;
      }
      canvas.toBlob(blob => {
        if (blob && blob.size > 0) resolve(blob);
        else reject(new Error("PNG image creation failed."));
      }, "image/png");
    });
  }

  // FileSharer and Printer receive validated RAW base64 (without data:image prefix).
  async function base64Of(canvas) {
    const blob = await blobOf(canvas);
    const dataURL = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error("Could not convert bill to PNG."));
      reader.readAsDataURL(blob);
    });
    if (typeof dataURL !== "string" || !dataURL.startsWith("data:image/png;base64,")) {
      throw new Error("Invalid PNG image data.");
    }
    const raw = dataURL.slice(dataURL.indexOf(",") + 1);
    if (raw.length < 100 || !raw.startsWith("iVBORw0KGgo")) {
      throw new Error("PNG image data is incomplete. Please try again.");
    }
    return raw;
  }

  /* DOWNLOAD */

  async function download() {
    const order = orderNow();
    if (!order) return;

    try {
      const canvas = createCanvas(order);
      const name = filename(order);

      requireAndroid();
      const saved = await FileSharer.save({
        filename: name,
        contentType: "image/png",
        base64Data: await base64Of(canvas),
        android: { saveDirectory: "pictures", relativePath: "SastaGo Bills" }
      });
      notify("Bill Gallery ke Pictures/SastaGo Bills folder mein save ho gaya.");
      console.log("Saved bill URI:", saved?.uri);

    } catch (error) {
      console.error("Download Error:", error);
      notify(error.message || "Bill download failed.");
    }
  }

  /* SHARE */

  async function share() {
    const order = orderNow();
    if (!order) return;

    try {
      const canvas = createCanvas(order);
      const name = filename(order);

      requireAndroid();
      await FileSharer.share({
        filename: name,
        contentType: "image/png",
        base64Data: await base64Of(canvas),
        title: "SastaGo Order Bill",
        text: "SastaGo Order Bill"
      });

    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Share Error:", error);
        notify(error.message || "Bill share failed.");
      }
    }
  }

  /* MOBILE / 58MM PRINT */

  async function print58() {
    const order = orderNow();
    if (!order) return;

    try {
      const canvas = createCanvas(order);
      const name = filename(order);

      requireAndroid();
      await Printer.printBase64({
        name,
        data: await base64Of(canvas),
        mimeType: "image/png"
      });

    } catch (error) {
      console.error("Print Error:", error);
      notify(error.message || "58mm print failed.");
    }
  }

  /* BUTTONS */

  function bind() {
    el("downloadBillPngBtn")
      ?.addEventListener("click", download);

    el("shareBillBtn")
      ?.addEventListener("click", share);

    el("print58BillBtn")
      ?.addEventListener("click", print58);
  }

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      bind
    );
  } else {
    bind();
  }

  /* GLOBAL FUNCTIONS */

  window.downloadAdminBillPNG = download;
  window.shareAdminBill = share;
  window.printAdminBill58mm = print58;

  window.SastaGoAdminBillTools = {
    download,
    share,
    print58,
    createCanvas,
    isAndroidApp
  };

  console.log(
    "SastaGo Admin Bill Tools: Android Only Ready"
  );

})();