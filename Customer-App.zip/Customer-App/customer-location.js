/* =====================================================
   SASTAGO CUSTOMER GPS LOCATION SYSTEM
   STARTUP LOCATION POPUP
   GOOGLE MAPS LOCATION LINK
   CHECKOUT LOCATION BUTTON
   ===================================================== */

(() => {
    "use strict";

    const MAP_FIELD_ID = "mapLink";

    const SESSION_KEY = "sastago_location_prompt_seen";
    const SAVED_LOCATION_KEY = "sastago_customer_location";

    let currentLocation = null;
    let isRequestingLocation = false;

    /* =================================================
       CSS
       ================================================= */

    function addLocationStyles() {
        if (document.getElementById("sastagoLocationStyles")) return;

        const style = document.createElement("style");

        style.id = "sastagoLocationStyles";

        style.textContent = `
            #sastagoLocationPrompt {
                display: none;
                position: fixed;
                inset: 0;
                z-index: 999999;
                background: rgba(0,0,0,.65);
                align-items: center;
                justify-content: center;
                padding: 18px;
            }

            #sastagoLocationPrompt.show {
                display: flex;
            }

            .sastago-location-modal {
                width: 100%;
                max-width: 380px;
                background: #fff;
                border-radius: 20px;
                padding: 25px 20px;
                text-align: center;
                box-shadow: 0 15px 45px rgba(0,0,0,.2);
                animation: sastagoLocationPopup .25s ease;
            }

            @keyframes sastagoLocationPopup {
                from {
                    opacity: 0;
                    transform: translateY(20px);
                }

                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .sastago-location-icon {
                width: 75px;
                height: 75px;
                margin: 0 auto 15px;
                border-radius: 50%;
                background: #e8f7ee;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 38px;
            }

            .sastago-location-modal h2 {
                color: #087b43;
                margin: 10px 0;
                font-size: 23px;
            }

            .sastago-location-modal p {
                color: #666;
                font-size: 14px;
                line-height: 1.6;
                margin: 10px 0 20px;
            }

            .sastago-location-btn {
                display: block;
                width: 100%;
                padding: 14px;
                margin-top: 10px;
                border: none;
                border-radius: 10px;
                font-size: 15px;
                font-weight: bold;
                cursor: pointer;
            }

            #sastagoAllowLocation {
                background: #087b43;
                color: #fff;
            }

            #sastagoSkipLocation {
                background: #f1f1f1;
                color: #555;
            }

            #sastagoLocationStatus,
            #sastagoCheckoutLocationStatus {
                display: block;
                margin-top: 10px;
                font-size: 13px;
                color: #087b43;
                line-height: 1.5;
            }

            .sastago-checkout-location {
                margin: 12px 0;
                padding: 14px;
                background: #f0faf4;
                border: 1px solid #ccebd8;
                border-radius: 10px;
            }

            .sastago-checkout-location button {
                width: 100%;
                padding: 12px;
                border: none;
                border-radius: 8px;
                background: #087b43;
                color: white;
                font-weight: bold;
                font-size: 14px;
                cursor: pointer;
            }

            .sastago-checkout-location button:disabled {
                opacity: .6;
            }
        `;

        document.head.appendChild(style);
    }

    /* =================================================
       CREATE LOCATION POPUP
       ================================================= */

    function createLocationPopup() {
        if (document.getElementById("sastagoLocationPrompt")) return;

        const modal = document.createElement("div");

        modal.id = "sastagoLocationPrompt";

        modal.innerHTML = `
            <div class="sastago-location-modal">

                <div class="sastago-location-icon">
                    📍
                </div>

                <h2>Turn On Location</h2>

                <p>
                    Allow SastaGo to access your current location
                    so we can make your delivery easier and share
                    your delivery point with our team.
                </p>

                <button
                    type="button"
                    id="sastagoAllowLocation"
                    class="sastago-location-btn"
                >
                    Allow Location
                </button>

                <button
                    type="button"
                    id="sastagoSkipLocation"
                    class="sastago-location-btn"
                >
                    Maybe Later
                </button>

                <span id="sastagoLocationStatus"></span>

            </div>
        `;

        document.body.appendChild(modal);

        document.getElementById("sastagoAllowLocation")
            .addEventListener("click", async () => {
                await requestSastaGoLocation("startup");
            });

        document.getElementById("sastagoSkipLocation")
            .addEventListener("click", () => {
                closeLocationPopup();
            });
    }

    /* =================================================
       CREATE CHECKOUT LOCATION BUTTON
       ================================================= */

    function createCheckoutLocationButton() {
        const mapField = document.getElementById(MAP_FIELD_ID);

        if (!mapField) return;

        if (document.getElementById("sastagoCheckoutLocationBox")) {
            return;
        }

        const box = document.createElement("div");

        box.id = "sastagoCheckoutLocationBox";
        box.className = "sastago-checkout-location";

        box.innerHTML = `
            <button
                type="button"
                id="sastagoCheckoutLocationBtn"
            >
                📍 Use My Current Location
            </button>

            <span id="sastagoCheckoutLocationStatus">
                Add your GPS location for easier delivery.
            </span>
        `;

        mapField.insertAdjacentElement("afterend", box);

        document.getElementById("sastagoCheckoutLocationBtn")
            .addEventListener("click", async () => {
                await requestSastaGoLocation("checkout");
            });
    }

    /* =================================================
       POPUP CONTROL
       ================================================= */

    function openLocationPopup() {
        const modal = document.getElementById("sastagoLocationPrompt");

        if (modal) modal.classList.add("show");
    }

    function closeLocationPopup() {
        const modal = document.getElementById("sastagoLocationPrompt");

        if (modal) modal.classList.remove("show");

        sessionStorage.setItem(SESSION_KEY, "yes");
    }

    /* =================================================
       STATUS
       ================================================= */

    function setLocationStatus(message, type = "success", target = "both") {
        const ids = [];

        if (target === "both" || target === "startup") {
            ids.push("sastagoLocationStatus");
        }

        if (target === "both" || target === "checkout") {
            ids.push("sastagoCheckoutLocationStatus");
        }

        ids.forEach(id => {
            const element = document.getElementById(id);

            if (!element) return;

            element.textContent = message;

            element.style.color = type === "error"
                ? "#d32f2f"
                : "#087b43";
        });
    }

    /* =================================================
       SAVE LOCATION
       ================================================= */

    function saveCustomerLocation(position) {
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;
        const accuracy = position.coords.accuracy;

        const mapLink =
            "https://www.google.com/maps?q=" +
            latitude + "," + longitude;

        currentLocation = {
            latitude,
            longitude,
            accuracy,
            mapLink,
            capturedAt: new Date().toISOString()
        };

        localStorage.setItem(
            SAVED_LOCATION_KEY,
            JSON.stringify(currentLocation)
        );

        const mapField = document.getElementById(MAP_FIELD_ID);

        if (mapField) {
            mapField.value = mapLink;

            mapField.dispatchEvent(
                new Event("input", { bubbles: true })
            );

            mapField.dispatchEvent(
                new Event("change", { bubbles: true })
            );
        }

        window.sastagoCustomerLocation = currentLocation;

        setLocationStatus(
            "Location added successfully! Your delivery map link is ready.",
            "success"
        );

        closeLocationPopup();

        if (typeof window.showToast === "function") {
            window.showToast("Current location added successfully!");
        }

        console.log("SastaGo GPS Location:", currentLocation);

        return currentLocation;
    }

    /* =================================================
       GEOLOCATION ERROR
       ================================================= */

    function handleLocationError(error, source) {
        let message = "Unable to get your location.";

        if (error.code === 1) {
            message =
                "Location permission denied. Please allow location access in your browser settings.";
        } else if (error.code === 2) {
            message =
                "Your location is unavailable. Please check your GPS.";
        } else if (error.code === 3) {
            message =
                "Location request timed out. Please try again.";
        }

        setLocationStatus(message, "error", source);

        if (typeof window.showToast === "function") {
            window.showToast(message, "error");
        }

        console.error("SastaGo Location Error:", error);

        isRequestingLocation = false;
    }

    /* =================================================
       REQUEST GPS LOCATION
       ================================================= */

    async function requestSastaGoLocation(source = "checkout") {
        if (isRequestingLocation) return;

        if (!navigator.geolocation) {
            setLocationStatus(
                "Your device does not support GPS location.",
                "error",
                source
            );
            return;
        }

        if (!window.isSecureContext) {
            setLocationStatus(
                "Location requires HTTPS. Please open the secure SastaGo app link.",
                "error",
                source
            );
            return;
        }

        isRequestingLocation = true;

        const button = document.getElementById(
            source === "checkout"
                ? "sastagoCheckoutLocationBtn"
                : "sastagoAllowLocation"
        );

        const originalText = button?.textContent;

        if (button) {
            button.disabled = true;
            button.textContent = "Getting Location...";
        }

        setLocationStatus(
            "Please wait. Getting your current location...",
            "success",
            source
        );

        navigator.geolocation.getCurrentPosition(
            position => {
                try {
                    saveCustomerLocation(position);
                } finally {
                    isRequestingLocation = false;

                    if (button) {
                        button.disabled = false;
                        button.textContent = originalText;
                    }
                }
            },

            error => {
                handleLocationError(error, source);

                if (button) {
                    button.disabled = false;
                    button.textContent = originalText;
                }
            },

            {
                enableHighAccuracy: true,
                timeout: 20000,
                maximumAge: 0
            }
        );
    }

    /* =================================================
       LOAD SAVED LOCATION
       ================================================= */

    function loadSavedLocation() {
        try {
            const saved = JSON.parse(
                localStorage.getItem(SAVED_LOCATION_KEY) || "null"
            );

            if (!saved || !saved.mapLink) return;

            currentLocation = saved;

            window.sastagoCustomerLocation = saved;

            const mapField = document.getElementById(MAP_FIELD_ID);

            if (mapField && !mapField.value) {
                mapField.value = saved.mapLink;
            }

        } catch (error) {
            console.error("Saved Location Error:", error);
        }
    }

    /* =================================================
       STARTUP
       ================================================= */

    async function initializeSastaGoLocation() {
        addLocationStyles();

        createLocationPopup();

        createCheckoutLocationButton();

        loadSavedLocation();

        if (sessionStorage.getItem(SESSION_KEY) === "yes") {
            return;
        }

        // If location permission is already granted,
        // do not show the startup popup again.

        if (navigator.permissions?.query) {
            try {
                const permission = await navigator.permissions.query({
                    name: "geolocation"
                });

                if (permission.state === "granted") {
                    sessionStorage.setItem(SESSION_KEY, "yes");

                    return;
                }

            } catch (error) {
                console.log("Permission status unavailable.");
            }
        }

        openLocationPopup();
    }

    /* =================================================
       GLOBAL GPS FUNCTION
       ================================================= */

    window.requestSastaGoLocation = requestSastaGoLocation;

    /* =================================================
       RUN
       ================================================= */

    if (document.readyState === "loading") {
        document.addEventListener(
            "DOMContentLoaded",
            initializeSastaGoLocation
        );
    } else {
        initializeSastaGoLocation();
    }

})();

/* ================= END OF SASTAGO GPS SYSTEM ================= */