const APP_CONFIG = {
    name: "SastaGo",
    shortName: "SastaGo",
    appType: "customer",
    icon: "./app-icons/customer-icon.png"
};

export default APP_CONFIG;