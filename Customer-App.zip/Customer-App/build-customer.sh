#!/usr/bin/env bash
set -euo pipefail

# =====================================================
# SASTAGO CUSTOMER APP BUILD SCRIPT
# Bundles customer JavaScript modules for Android WebView
# =====================================================

echo "Starting SastaGo Customer App Build..."

# =====================================================
# CHECK REQUIRED TOOLS
# =====================================================

for tool in node npm python3; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        echo "ERROR: $tool is not installed."
        exit 1
    fi
done

if [ ! -d "node_modules" ]; then
    echo "ERROR: node_modules not found. Run npm install first."
    exit 1
fi

# =====================================================
# CHECK SOURCE FILES
# =====================================================

for file in customer.js customer-location.js customer-bill-tools.js; do
    if [ ! -s "$file" ]; then
        echo "ERROR: Missing or empty source file: $file"
        exit 1
    fi
done

# =====================================================
# CHECK ESBUILD
# =====================================================

if [ ! -x "node_modules/.bin/esbuild" ]; then
    echo "Installing esbuild..."
    npm install --save-dev esbuild
fi

# =====================================================
# BUILD CUSTOMER BUNDLES
# =====================================================

echo "Building customer.js..."

npx esbuild customer.js \
    --bundle \
    --format=esm \
    --platform=browser \
    --target=es2020 \
    --external:https://* \
    --outfile=customer.bundle.js

echo "Building customer-location.js..."

npx esbuild customer-location.js \
    --bundle \
    --format=esm \
    --platform=browser \
    --target=es2020 \
    --external:https://* \
    --outfile=customer-location.bundle.js

echo "Building customer-bill-tools.js..."

npx esbuild customer-bill-tools.js \
    --bundle \
    --format=esm \
    --platform=browser \
    --target=es2020 \
    --external:https://* \
    --outfile=customer-bill-tools.bundle.js

# =====================================================
# UPDATE HTML SCRIPT REFERENCES
# =====================================================

python3 - <<'PY'
from pathlib import Path
import re

html_files = ["customer.html", "product.html"]

replacements = {
    "customer.js": "customer.bundle.js",
    "customer-location.js": "customer-location.bundle.js",
    "customer-bill-tools.js": "customer-bill-tools.bundle.js",
}

for filename in html_files:

    path = Path(filename)

    if not path.is_file():
        raise SystemExit(
            f"ERROR: Required HTML file missing: {filename}"
        )

    html = path.read_text(encoding="utf-8")

    for old, new in replacements.items():

        pattern = (
            r'(<script\b[^>]*\bsrc=["\'])'
            r'(\./)?'
            + re.escape(old)
            + r'(["\'])'
        )

        html, count = re.subn(
            pattern,
            lambda match: match.group(1) + new + match.group(3),
            html,
            flags=re.IGNORECASE
        )

        print(
            f"{filename}: {old} -> {new} "
            f"({count} reference(s))"
        )

    for old in replacements:

        if re.search(
            r'\bsrc=["\'](?:\./)?'
            + re.escape(old)
            + r'["\']',
            html,
            flags=re.IGNORECASE
        ):
            raise SystemExit(
                f"ERROR: Old JavaScript reference remains "
                f"in {filename}: {old}"
            )

    def add_module(match):

        tag = match.group(0)

        if re.search(r'\btype\s*=', tag, flags=re.IGNORECASE):

            tag = re.sub(
                r'\btype\s*=\s*(["\']).*?\1',
                'type="module"',
                tag,
                count=1,
                flags=re.IGNORECASE
            )

        else:
            tag = tag.replace(
                "<script",
                '<script type="module"',
                1
            )

        return tag

    html = re.sub(
        r'<script\b[^>]*\bsrc=["\'](?:\./)?'
        r'(?:customer\.bundle\.js|'
        r'customer-location\.bundle\.js|'
        r'customer-bill-tools\.bundle\.js)'
        r'["\'][^>]*>',
        add_module,
        html,
        flags=re.IGNORECASE
    )

    path.write_text(html, encoding="utf-8")

# =====================================================
# VERIFY OUTPUT FILES
# =====================================================

bundles = [
    "customer.bundle.js",
    "customer-location.bundle.js",
    "customer-bill-tools.bundle.js"
]

for filename in bundles:

    path = Path(filename)

    if not path.is_file() or path.stat().st_size == 0:
        raise SystemExit(
            f"ERROR: Build output missing or empty: {filename}"
        )

    print(
        f"Verified: {filename} "
        f"({path.stat().st_size} bytes)"
    )

print("HTML references updated successfully.")

PY

# =====================================================
# BUILD COMPLETE
# =====================================================

echo ""
echo "============================================"
echo " SASTAGO CUSTOMER BUILD SUCCESSFUL"
echo "============================================"
echo "Generated files:"
echo "  customer.bundle.js"
echo "  customer-location.bundle.js"
echo "  customer-bill-tools.bundle.js"
echo ""
echo "HTML files updated."
echo "============================================"