#!/usr/bin/env bash
set -euo pipefail

echo "Starting SastaGo Customer App Build..."

# Check required tools
for tool in node npm python3; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        echo "ERROR: $tool is missing"
        exit 1
    fi
done

# Check source files
for file in customer.js customer-location.js customer-bill-tools.js customer.html; do
    if [ ! -s "$file" ]; then
        echo "ERROR: Missing file: $file"
        exit 1
    fi
done

# Check esbuild
if [ ! -x node_modules/.bin/esbuild ]; then
    npm install --save-dev esbuild
fi

# Build JavaScript bundles
echo "Building customer JavaScript..."

npx esbuild customer.js \
    --bundle \
    --format=esm \
    --platform=browser \
    --target=es2020 \
    --external:https://* \
    --outfile=customer.bundle.js

npx esbuild customer-location.js \
    --bundle \
    --format=esm \
    --platform=browser \
    --target=es2020 \
    --external:https://* \
    --outfile=customer-location.bundle.js

npx esbuild customer-bill-tools.js \
    --bundle \
    --format=esm \
    --platform=browser \
    --target=es2020 \
    --external:https://* \
    --outfile=customer-bill-tools.bundle.js

# Create www directory
rm -rf www
mkdir -p www

# Copy customer HTML as Capacitor entry point
cp customer.html www/index.html

# Also keep original filename
cp customer.html www/customer.html

# Copy product page if available
if [ -f product.html ]; then
    cp product.html www/product.html
fi

# Copy required configuration
for file in firebase.js manifest.json favicon.ico; do
    if [ -f "$file" ]; then
        cp "$file" www/
    fi
done

# Copy asset folders
for folder in assets images icons css js fonts; do
    if [ -d "$folder" ]; then
        cp -R "$folder" www/
    fi
done

# Update JavaScript references in both HTML files
python3 - <<'PY'
from pathlib import Path
import re

files = [
    Path("www/index.html"),
    Path("www/customer.html")
]

replacements = {
    "customer.js": "customer.bundle.js",
    "customer-location.js": "customer-location.bundle.js",
    "customer-bill-tools.js": "customer-bill-tools.bundle.js"
}

for path in files:
    html = path.read_text(encoding="utf-8")

    for old, new in replacements.items():
        html = re.sub(
            r'(<script\b[^>]*\bsrc=["\'])(?:\./)?'
            + re.escape(old)
            + r'(["\'])',
            lambda m: m.group(1) + new + m.group(2),
            html,
            flags=re.IGNORECASE
        )

    path.write_text(html, encoding="utf-8")

    print(f"Updated: {path}")
PY

# Copy bundles
cp customer.bundle.js www/
cp customer-location.bundle.js www/
cp customer-bill-tools.bundle.js www/

# Verify entry point
if [ ! -s www/index.html ]; then
    echo "ERROR: www/index.html was not created"
    exit 1
fi

# Verify bundles
for file in customer.bundle.js customer-location.bundle.js customer-bill-tools.bundle.js; do
    if [ ! -s "www/$file" ]; then
        echo "ERROR: Missing bundle: $file"
        exit 1
    fi
done

echo "======================================"
echo " SASTAGO CUSTOMER BUILD SUCCESSFUL"
echo "======================================"
echo "Web entry point: www/index.html"
echo "JavaScript bundles created successfully."