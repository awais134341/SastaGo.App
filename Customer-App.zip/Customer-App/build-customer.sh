#!/usr/bin/env bash
set -euo pipefail

echo "Starting SastaGo Customer Build..."

# Check tools
for tool in node npm python3; do
    command -v "$tool" >/dev/null 2>&1 || {
        echo "ERROR: $tool missing"
        exit 1
    }
done

# Check required files
for file in customer.js customer-location.js customer-bill-tools.js customer.html; do
    if [ ! -s "$file" ]; then
        echo "ERROR: Missing file: $file"
        exit 1
    fi
done

# Check esbuild
if [ ! -x node_modules/.bin/esbuild ]; then
    npm install --save-dev esbuild
fi

# Build JavaScript bundles
npx esbuild customer.js \
    --bundle \
    --format=esm \
    --platform=browser \
    --target=es2020 \
    --external:https://* \
    --outfile=customer.bundle.js

npx esbuild customer-location.js \
    --bundle \
    --format=esm \
    --platform=browser \
    --target=es2020 \
    --external:https://* \
    --outfile=customer-location.bundle.js

npx esbuild customer-bill-tools.js \
    --bundle \
    --format=esm \
    --platform=browser \
    --target=es2020 \
    --external:https://* \
    --outfile=customer-bill-tools.bundle.js

# Create www folder
rm -rf www
mkdir -p www

# Copy HTML files
cp customer.html www/

if [ -f product.html ]; then
    cp product.html www/
fi

# Copy other required assets
for folder in assets images icons css js; do
    if [ -d "$folder" ]; then
        cp -R "$folder" www/
    fi
done

# Copy Firebase configuration
for file in firebase.js manifest.json favicon.ico; do
    if [ -f "$file" ]; then
        cp "$file" www/
    fi
done

# Update HTML references
python3 - <<'PY'
from pathlib import Path
import re

path = Path("www/customer.html")
html = path.read_text(encoding="utf-8")

replacements = {
    "customer.js": "customer.bundle.js",
    "customer-location.js": "customer-location.bundle.js",
    "customer-bill-tools.js": "customer-bill-tools.bundle.js",
}

for old, new in replacements.items():
    html = re.sub(
        r'(<script\b[^>]*\bsrc=["\'])(?:\./)?'
        + re.escape(old)
        + r'(["\'])',
        lambda m: m.group(1) + new + m.group(2),
        html,
        flags=re.IGNORECASE
    )

path.write_text(html, encoding="utf-8")
PY

# Copy bundles
cp customer.bundle.js www/
cp customer-location.bundle.js www/
cp customer-bill-tools.bundle.js www/

# Verify
if [ ! -s www/customer.html ]; then
    echo "ERROR: customer.html missing"
    exit 1
fi

for file in customer.bundle.js customer-location.bundle.js customer-bill-tools.bundle.js; do
    if [ ! -s "www/$file" ]; then
        echo "ERROR: Bundle missing: $file"
        exit 1
    fi
done

echo "SastaGo Customer Web Build Successful!"