#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

# Bundle local JS and native Capacitor plugins for Android WebView.
npx esbuild customer.js --bundle --format=esm --platform=browser --target=es2020 --external:https://* --outfile=customer.bundle.js
npx esbuild customer-location.js --bundle --format=esm --platform=browser --target=es2020 --external:https://* --outfile=customer-location.bundle.js
npx esbuild customer-bill-tools.js --bundle --format=esm --platform=browser --target=es2020 --external:https://* --outfile=customer-bill-tools.bundle.js

rm -rf www
mkdir -p www
cp customer.html customer.css customer.bundle.js customer-location.bundle.js customer-bill-tools.bundle.js firebase.js product.html Intro.html sastago-icon.png www/
cp Intro.html www/index.html

# Replace module entry points with bundled versions in the Android web directory.
python3 - <<'PY'
from pathlib import Path
for filename in ("customer.html", "product.html"):
    path = Path("www") / filename
    html = path.read_text()
    html = html.replace('src="customer.js"', 'src="customer.bundle.js"')
    html = html.replace('src="./customer.js"', 'src="./customer.bundle.js"')
    html = html.replace('src="customer-location.js"', 'src="customer-location.bundle.js"')
    html = html.replace('src="./customer-location.js"', 'src="./customer-location.bundle.js"')
    html = html.replace('src="customer-bill-tools.js"', 'src="customer-bill-tools.bundle.js"')
    html = html.replace('src="./customer-bill-tools.js"', 'src="customer-bill-tools.bundle.js"')
    path.write_text(html)

for filename in ("customer.bundle.js", "customer-location.bundle.js", "customer-bill-tools.bundle.js"):
    path = Path("www") / filename
    if not path.exists() or path.stat().st_size == 0:
        raise SystemExit(f"Build failed: {filename} missing or empty")
PY

echo "SastaGo Customer web build created in: $ROOT/www"
