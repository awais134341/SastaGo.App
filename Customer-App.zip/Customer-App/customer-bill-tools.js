/* =====================================================
   SASTAGO ANDROID BILL TOOLS
   ANDROID DOWNLOAD / SHARE / 58MM PRINT
   BROWSER FALLBACK INCLUDED
   ===================================================== */

import { Capacitor } from "@capacitor/core";
import { FileSharer } from "@capgo/capacitor-file-sharer";
import { Printer } from "@capgo/capacitor-printer";

const isNative = Capacitor.isNativePlatform();

function notify(message, type = "success") {
    if (window.sastagoShowToast) {
        window.sastagoShowToast(message, type);
    } else {
        alert(message);
    }
}

function findOrder(orderId) {
    const orders = window.sastagoCustomerOrders || [];
    return orders.find(order => order.id === orderId);
}

function createCanvas(order) {
    if (typeof window.sastagoCreateBillCanvas !== "function") {
        throw new Error("Bill generator is not connected.");
    }

    return window.sastagoCreateBillCanvas(order);
}

function getFileName(order) {
    const number = String(order.orderNumber || order.id)
        .replace(/[^a-zA-Z0-9-]/g, "");

    return `SastaGo-${number}.png`;
}

function getBase64(canvas) {
    const dataURL = canvas.toDataURL("image/png");
    return dataURL.split(",")[1];
}

function canvasToBlob(canvas) {
    return new Promise((resolve, reject) => {
        canvas.toBlob(blob => {
            if (blob) resolve(blob);
            else reject(new Error("Could not create bill PNG."));
        }, "image/png");
    });
}

/* =====================================================
   DOWNLOAD BILL
   ===================================================== */

async function downloadOrderPNG(orderId) {
    try {
        const order = findOrder(orderId);

        if (!order) {
            throw new Error("Order not found.");
        }

        const canvas = createCanvas(order);
        const filename = getFileName(order);

        if (isNative && Capacitor.getPlatform() === "android") {
            const base64Data = getBase64(canvas);

            const result = await FileSharer.save({
                filename,
                contentType: "image/png",
                base64Data,
                android: {
                    saveDirectory: "downloads",
                    relativePath: "Download/SastaGo"
                }
            });

            notify("Bill Downloads folder mein save ho gaya!");
            console.log("Saved bill:", result?.uri);
            return;
        }

        // Browser fallback
        const blob = await canvasToBlob(canvas);
        const url = URL.createObjectURL(blob);

        const link = document.createElement("a");
        link.href = url;
        link.download = filename;

        document.body.appendChild(link);
        link.click();
        link.remove();

        setTimeout(() => URL.revokeObjectURL(url), 3000);

        notify("Bill PNG downloaded!");

    } catch (error) {
        console.error("Bill Download Error:", error);
        notify(error.message || "Bill download failed.", "error");
    }
}

/* =====================================================
   SHARE BILL
   ===================================================== */

async function shareOrderPNG(orderId) {
    try {
        const order = findOrder(orderId);

        if (!order) {
            throw new Error("Order not found.");
        }

        const canvas = createCanvas(order);
        const filename = getFileName(order);

        if (isNative) {
            await FileSharer.share({
                filename,
                contentType: "image/png",
                base64Data: getBase64(canvas),
                title: "SastaGo Order Bill",
                text: "SastaGo Order Bill"
            });

            return;
        }

        // Browser native share fallback
        const blob = await canvasToBlob(canvas);

        const file = new File(
            [blob],
            filename,
            { type: "image/png" }
        );

        if (
            navigator.share &&
            navigator.canShare &&
            navigator.canShare({ files: [file] })
        ) {
            await navigator.share({
                title: "SastaGo Order Bill",
                text: "My SastaGo Order Bill",
                files: [file]
            });
        } else {
            await downloadOrderPNG(orderId);
            notify("Bill download ho gaya. Ab WhatsApp par attach karein.");
        }

    } catch (error) {
        if (error.name === "AbortError") return;

        console.error("Bill Share Error:", error);
        notify(error.message || "Bill share failed.", "error");
    }
}

/* =====================================================
   PRINT 58MM BILL
   ===================================================== */

async function printOrderPNG(orderId) {
    let printWindow = null;

    try {
        const order = findOrder(orderId);

        if (!order) {
            throw new Error("Order not found.");
        }

        const canvas = createCanvas(order);

        if (isNative) {
            await Printer.printBase64({
                name: getFileName(order),
                data: getBase64(canvas),
                mimeType: "image/png"
            });

            return;
        }

        // Browser print fallback
        printWindow = window.open("", "_blank");

        if (!printWindow) {
            throw new Error("Popup blocked. Please allow popups.");
        }

        const imageURL = canvas.toDataURL("image/png");

        printWindow.document.open();

        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>SastaGo Bill</title>
                <meta name="viewport" content="width=device-width, initial-scale=1">

                <style>
                    @page {
                        size: 58mm auto;
                        margin: 0;
                    }

                    html, body {
                        margin: 0;
                        padding: 0;
                        width: 58mm;
                        background: white;
                    }

                    img {
                        display: block;
                        width: 58mm;
                        height: auto;
                    }
                </style>
            </head>

            <body>
                <img id="billImage" src="${imageURL}" alt="SastaGo Bill">

                <script>
                    const img = document.getElementById("billImage");

                    img.onload = function() {
                        setTimeout(() => window.print(), 400);
                    };
                <\/script>
            </body>
            </html>
        `);

        printWindow.document.close();

    } catch (error) {
        console.error("Bill Print Error:", error);

        if (printWindow && !printWindow.closed) {
            printWindow.close();
        }

        notify(error.message || "Bill printing failed.", "error");
    }
}

/* =====================================================
   GLOBAL FUNCTIONS
   ===================================================== */

window.downloadOrderPNG = downloadOrderPNG;
window.shareOrderPNG = shareOrderPNG;
window.printOrderPNG = printOrderPNG;

console.log("SastaGo Bill Tools Initialized.");