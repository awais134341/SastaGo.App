/* =====================================================
   SASTAGO ANDROID BILL TOOLS
   ANDROID GALLERY SAVE / SHARE / 58MM PRINT
   BROWSER FALLBACK INCLUDED
   ===================================================== */

import { Capacitor } from "@capacitor/core";
import { FileSharer } from "@capgo/capacitor-file-sharer";
import { Printer } from "@capgo/capacitor-printer";

function isAndroidApp() {
    return Capacitor.isNativePlatform() && Capacitor.getPlatform() === "android";
}

function requireAndroid() {
    if (!isAndroidApp()) {
        throw new Error("Yeh feature sirf SastaGo Android app mein available hai.");
    }
}

function notify(message, type = "success") {
    if (window.sastagoShowToast) {
        window.sastagoShowToast(message, type);
    } else {
        alert(message);
    }
}

function findOrder(orderId) {
    const orders = window.sastagoCustomerOrders || [];
    return orders.find(order => String(order.id) === String(orderId) || String(order.orderNumber) === String(orderId));
}

function createCanvas(order) {
    if (typeof window.sastagoCreateBillCanvas !== "function") {
        throw new Error("Bill generator is not connected.");
    }

    return window.sastagoCreateBillCanvas(order);
}

function getFileName(order) {
    const number = String(order.orderNumber || order.id)
        .replace(/[^a-zA-Z0-9-]/g, "");

    return `SastaGo-${number}.png`;
}

function canvasToBlob(canvas) {
    if (!canvas || !canvas.width || !canvas.height) {
        return Promise.reject(new Error("Bill image is empty. Please reopen the order bill and try again."));
    }

    return new Promise((resolve, reject) => {
        if (typeof canvas.toBlob !== "function") {
            reject(new Error("This device cannot create a PNG image."));
            return;
        }

        canvas.toBlob(blob => {
            if (blob && blob.size > 0) {
                resolve(blob);
            } else {
                reject(new Error("PNG image could not be created. Please try again."));
            }
        }, "image/png");
    });
}

// Create one validated raw Base64 PNG payload for native plugins.
async function getRawBase64(canvas) {
    const blob = await canvasToBlob(canvas);
    const dataURL = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error("Could not convert bill to PNG."));
        reader.readAsDataURL(blob);
    });
    if (typeof dataURL !== "string" || !dataURL.startsWith("data:image/png;base64,")) {
        throw new Error("PNG image data is invalid. Please try again.");
    }
    const raw = dataURL.slice(dataURL.indexOf(",") + 1);
    if (raw.length < 100 || !raw.startsWith("iVBORw0KGgo")) {
        throw new Error("Bill PNG is empty or invalid. Please reopen the bill and try again.");
    }
    return raw;
}

/* =====================================================
   DOWNLOAD BILL
   ===================================================== */

async function downloadOrderPNG(orderId) {
    try {
        const order = findOrder(orderId);

        if (!order) {
            throw new Error("Order not found.");
        }

        const canvas = createCanvas(order);
        const filename = getFileName(order);

        requireAndroid();
        const base64Data = await getRawBase64(canvas);

        const result = await FileSharer.save({
            filename,
            contentType: "image/png",
            base64Data,
            android: {
                saveDirectory: "pictures",
                relativePath: "SastaGo Bills"
            }
        });

        notify("Bill Gallery ke Pictures/SastaGo Bills folder mein save ho gaya!");
        console.log("Saved bill:", result?.uri);

    } catch (error) {
        console.error("Bill Download Error:", error);
        notify(error.message || "Bill download failed.", "error");
    }
}

/* =====================================================
   SHARE BILL
   ===================================================== */

async function shareOrderPNG(orderId) {
    try {
        const order = findOrder(orderId);

        if (!order) {
            throw new Error("Order not found.");
        }

        const canvas = createCanvas(order);
        const filename = getFileName(order);

        requireAndroid();
        await FileSharer.share({
            filename,
            contentType: "image/png",
            base64Data: await getRawBase64(canvas),
            title: "SastaGo Order Bill",
            text: "SastaGo Order Bill"
        });

    } catch (error) {
        if (error.name === "AbortError") return;

        console.error("Bill Share Error:", error);
        notify(error.message || "Bill share failed.", "error");
    }
}

/* =====================================================
   PRINT 58MM BILL
   ===================================================== */

async function printOrderPNG(orderId) {
    try {
        const order = findOrder(orderId);

        if (!order) {
            throw new Error("Order not found.");
        }

        const canvas = createCanvas(order);

        requireAndroid();
        await Printer.printBase64({
            name: getFileName(order),
            data: await getRawBase64(canvas),
            mimeType: "image/png"
        });

    } catch (error) {
        console.error("Bill Print Error:", error);

        notify(error.message || "Bill printing failed.", "error");
    }
}

/* =====================================================
   GLOBAL FUNCTIONS
   ===================================================== */

window.downloadOrderPNG = downloadOrderPNG;
window.shareOrderPNG = shareOrderPNG;
window.printOrderPNG = printOrderPNG;

console.log("SastaGo Bill Tools Initialized.");