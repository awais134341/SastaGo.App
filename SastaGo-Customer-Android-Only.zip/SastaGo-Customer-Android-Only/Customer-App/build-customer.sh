#!/usr/bin/env bash
set -euo pipefail

# Run from Customer-App after npm install. Bundle each separate feature module
# for Android WebView, then copy the complete customer app into Capacitor webDir.

npx esbuild customer.js --bundle --format=esm --platform=browser --target=es2020 --external:https://* --outfile=customer.bundle.js
npx esbuild customer-location.js --bundle --format=esm --platform=browser --target=es2020 --external:https://* --outfile=customer-location.bundle.js
npx esbuild customer-bill-tools.js --bundle --format=esm --platform=browser --target=es2020 --external:https://* --outfile=customer-bill-tools.bundle.js

python3 - <<'PYCODE'
from pathlib import Path
replacements = {
    'src="customer.js"': 'src="customer.bundle.js"',
    'src="./customer.js"': 'src="customer.bundle.js"',
    'src="customer-location.js"': 'src="customer-location.bundle.js"',
    'src="./customer-location.js"': 'src="customer-location.bundle.js"',
    'src="customer-bill-tools.js"': 'src="customer-bill-tools.bundle.js"',
    'src="./customer-bill-tools.js"': 'src="customer-bill-tools.bundle.js"',
}
out = Path('www')
out.mkdir(exist_ok=True)
for name in ('customer.html', 'product.html'):
    html = Path(name).read_text()
    for old, new in replacements.items():
        html = html.replace(old, new)
    (out / name).write_text(html)
for name in ('customer.css', 'Intro.html', 'app-config.js', 'firebase.js',
             'customer.bundle.js', 'customer-location.bundle.js',
             'customer-bill-tools.bundle.js'):
    src = Path(name)
    if src.exists():
        (out / name).write_bytes(src.read_bytes())
for folder in ('resources', 'app-icons'):
    src = Path(folder)
    if src.exists():
        import shutil
        shutil.copytree(src, out / folder, dirs_exist_ok=True)
for name in ('customer.bundle.js', 'customer-location.bundle.js', 'customer-bill-tools.bundle.js'):
    target = out / name
    if not target.exists() or target.stat().st_size == 0:
        raise SystemExit(f'Build failed: {target} missing or empty')
PYCODE

echo 'SastaGo customer web build created in Customer-App/www.'
