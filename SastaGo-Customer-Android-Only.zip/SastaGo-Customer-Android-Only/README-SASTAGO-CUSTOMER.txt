SASTAGO CUSTOMER ANDROID APP
============================

Project folder: Customer-App
Firebase project: sastago-85c78
App ID: pk.sastago.customer
WhatsApp order number: 03060965926

IMPORTANT FEATURE SEPARATION
----------------------------
- customer.js: products, cart, checkout, Firebase orders, WhatsApp order text, and bill canvas renderer.
- customer-location.js: GPS permission, current location capture, saved location, and Google Maps link.
- customer-gps-capacitor.js: Capacitor GPS support helper retained as a separate source file.
- customer-bill-tools.js: PNG download, image sharing, and 58mm printing.

The WhatsApp order message includes the delivery map/GPS map link when a location is available.
The generated bill image includes the saved delivery map and GPS coordinates when available.
If GPS permission is denied, the customer can still submit a complete manual address; the bill states that GPS was not shared.

CHECKOUT RULES
--------------
- Subtotal Rs. 2,500 or above: free delivery.
- Subtotal below Rs. 2,500: Rs. 50 delivery.
- Fixed Rs. 10 service charge on every non-empty cart order.
- Cash on Delivery only.
- City is not required; complete delivery address is required.

BUILD FOR ANDROID
-----------------
1. Install Node.js LTS and Android Studio.
2. Open a terminal in Customer-App.
3. Run: npm install
4. Run: npm run build:web
5. First Android setup only: npm run cap:add
6. Run: npx cap sync android
7. Run: npm run cap:open
8. In Android Studio, build the APK.

This ZIP contains source code and build configuration. An APK is not included, and actual device/Firebase/GPS/WhatsApp testing is still required.
