const APP_CONFIG = {
  name: "SastaGo",
  shortName: "SastaGo",
  appType: "customer",
  startPage: "./Intro.html",
  icon: "./app-icons/sastago-icon.svg"
};

export default APP_CONFIG;
